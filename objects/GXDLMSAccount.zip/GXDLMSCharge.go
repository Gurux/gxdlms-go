﻿package objects

//
// --------------------------------------------------------------------------
//  Gurux Ltd
//
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// More information of Gurux products: https://www.gurux.org
//
// This code is licensed under the GNU General Public License v2.
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

import (
	"fmt"
	"gurux.dlms"
	"github.com/Gurux/gxdlms-go/enums"
	"github.com/Gurux/gxdlms-go/types"
	"time"
)

// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
type GXDLMSCharge struct {
	GXDLMSObject
	// Total amount paid
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	TotalAmountPaid int32

	// Charge type.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	ChargeType ChargeType

	// Priority.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	Priority uint8

	// Unit charge active.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	UnitChargeActive GXUnitCharge

	// Unit charge passive.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	UnitChargePassive GXUnitCharge

	// Unit charge activation time.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	UnitChargeActivationTime dlms.GXDateTime

	// Period.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	Period uint32

	// Charge configuration,
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	ChargeConfiguration enums.ChargeConfiguration

	// Last collection time.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	LastCollectionTime dlms.GXDateTime

	// Last collection amount.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	LastCollectionAmount int32

	// Total amount remaining.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	TotalAmountRemaining int32

	// Proportion.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCharge
	Proportion uint16
}

// Base returns the base GXDLMSObject of the object.
func (g *GXDLMSCharge) Base() *GXDLMSObject {
	return &g.GXDLMSObject
}

//Invoke returns the invokes method.
//
// Parameters:
//   settings: DLMS settings.
//   e: Invoke parameters.
func (g *GXDLMSCharge) Invoke(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) []byte {
	e.Error = enums.ErrorCodeReadWriteDenied
	return nil
}

//GetAttributeIndexToRead returns the collection of attributes to read.
// If attribute is static and already read or device is returned HW error it is not returned.
//
// Parameters:
//   all: All items are returned even if they are read already.
//
// Returns:
//   Collection of attributes to read.
func (g *GXDLMSCharge) GetAttributeIndexToRead(all bool) []int {
	var attributes []int
	// LN is static and read only once.
	if all || g.LogicalName() == "" {
		attributes = append(attributes, 1)
	}
	// TotalAmountPaid
	if all || g.CanRead(2) {
		attributes = append(attributes, 2)
	}
	// ChargeType
	if all || g.CanRead(3) {
		attributes = append(attributes, 3)
	}
	// Priority
	if all || g.CanRead(4) {
		attributes = append(attributes, 4)
	}
	// UnitChargeActive
	if all || g.CanRead(5) {
		attributes = append(attributes, 5)
	}
	// UnitChargePassive
	if all || g.CanRead(6) {
		attributes = append(attributes, 6)
	}
	// UnitChargeActivationTime
	if all || g.CanRead(7) {
		attributes = append(attributes, 7)
	}
	// Period
	if all || g.CanRead(8) {
		attributes = append(attributes, 8)
	}
	// ChargeConfiguration
	if all || g.CanRead(9) {
		attributes = append(attributes, 9)
	}
	// LastCollectionTime
	if all || g.CanRead(10) {
		attributes = append(attributes, 10)
	}
	// LastCollectionAmount
	if all || g.CanRead(11) {
		attributes = append(attributes, 11)
	}
	// TotalAmountRemaining
	if all || g.CanRead(12) {
		attributes = append(attributes, 12)
	}
	// Proportion
	if all || g.CanRead(13) {
		attributes = append(attributes, 13)
	}
	return attributes
}

//GetNames returns the names of attribute indexes.
func (g *GXDLMSCharge) GetNames() []string {
	return []string{"Logical Name", "TotalAmountPaid", "ChargeType", "Priority", "UnitChargeActive", "UnitChargePassive", "UnitChargeActivationTime", "Period", "ChargeConfiguration", "LastCollectionTime", "LastCollectionAmount", "TotalAmountRemaining", "Proportion"}
}

//GetMethodNames returns the names of method indexes.
func (g *GXDLMSCharge) GetMethodNames() []string {
	return []string{"Update unit charge", "Activate passive unit charge", "Collect", "Update total amount remaining", "Set total amount remaining"}
}

//GetAttributeCount returns the amount of attributes.
//
// Returns:
//   Count of attributes.
func (g *GXDLMSCharge) GetAttributeCount() int {
	return 13
}

//GetMethodCount returns the amount of methods.
func (g *GXDLMSCharge) GetMethodCount() int {
	return 5
}

// TODO: Comment is missing.
func (g *GXDLMSCharge) GetUnitCharge(settings *settings.GXDLMSSettings, charge *GXUnitCharge) ([]byte, error) {
	bb := GXByteBuffer{}
	err = bb.SetUInt8(enums.DataTypeStructure)	
	if err != nil {
		return err
	}
	err = bb.SetUInt8(3)	
	if err != nil {
		return err
	}
	err = bb.SetUInt8(enums.DataTypeStructure)	
	if err != nil {
		return err
	}
	err = bb.SetUInt8(2)	
	if err != nil {
		return err
	}
	GXCommon.SetData(settings, bb, enums.DataTypeInt8, charge.ChargePerUnitScaling.g.CommodityScale)
	GXCommon.SetData(settings, bb, enums.DataTypeInt8, charge.ChargePerUnitScaling.g.PriceScale)
	err = bb.SetUInt8(enums.DataTypeStructure)	
	if err != nil {
		return err
	}
	err = bb.SetUInt8(3)	
	if err != nil {
		return err
	}
	if charge.Commodity.g.Target == nil {
		GXCommon.SetData(settings, bb, enums.DataTypeUInt16, 0)
		err = bb.SetUInt8(enums.DataTypeOctetString)		
		if err != nil {
			return err
		}
		err = bb.SetUInt8(6)		
		if err != nil {
			return err
		}
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
		GXCommon.SetData(settings, bb, enums.DataTypeInt8, 0)
	} else {
		// TODO: MIKKO: FAILED
		// GXCommon.SetData(settings, bb, DataType.UInt16, charge.Commodity.Target.ObjectType);
		// Method not implemented. GXUnitCharge.Commodity.Target
		// TODO: MIKKO: FAILED
		// GXCommon.SetData(settings, bb, DataType.OctetString, GXCommon.LogicalNameToBytes(charge.Commodity.Target.LogicalName));
		// Method not implemented. GXUnitCharge.Commodity.Target
		GXCommon.SetData(settings, bb, enums.DataTypeInt8, charge.Commodity.g.Index)
	}
	err = bb.SetUInt8(enums.DataTypeArray)	
	if err != nil {
		return err
	}
	if charge.ChargeTables() == nil {
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
	} else {
		GXCommon.SetObjectCount(len(charge.ChargeTables), bb)
		for _, it := range charge.ChargeTables() {
			err = bb.SetUInt8(enums.DataTypeStructure)			
			if err != nil {
				return err
			}
			err = bb.SetUInt8(2)			
			if err != nil {
				return err
			}
			GXCommon.SetData(settings, bb, enums.DataTypeOctetString, []byte(it.g.Index))
			GXCommon.SetData(settings, bb, enums.DataTypeInt16, it.ChargePerUnit())
		}
	}
	return bb.Array(), nil
}

//GetValue returns the value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Get parameters.
//
// Returns:
//   Value of the attribute index.
func (g *GXDLMSCharge) GetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) (any, error) {
	switch (e.Index) {
	case 1:
		return GXCommon.LogicalNameToBytes(g.LogicalName)
	case 2:
		return g.TotalAmountPaid
	case 3:
		return ChargeType
	case 4:
		return Priority
	case 5:
		return g.GetUnitCharge(settings, g.UnitChargeActive)
	case 6:
		return g.GetUnitCharge(settings, g.UnitChargePassive)
	case 7:
		return g.UnitChargeActivationTime
	case 8:
		return g.Period
	case 9:
		return types.GXBitString (uint32(), 2)
	case 10:
		return g.LastCollectionTime
	case 11:
		return g.LastCollectionAmount
	case 12:
		return g.TotalAmountRemaining
	case 13:
		return g.Proportion
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
	return nil
}

func (g *GXDLMSCharge) SetUnitCharge(charge *GXUnitCharge, value *any) {
	if value != nil {
		var tmp []		var tmp2 []		var it []
if _, ok := value.(List[any]); ok {
			tmp = []<any>(value)
		} else {
			tmp = [](any(value))
		}
if _, ok := tmp[0].(List[any]); ok {
			tmp2 = []<any>(tmp[0])
		} else {
			tmp2 = [](any(tmp[0]))
		}
		charge.ChargePerUnitScaling.g.CommodityScale(int8(tmp2[0]))
		charge.ChargePerUnitScaling.g.PriceScale(int8(tmp2[1]))
if _, ok := tmp[1].(List[any]); ok {
			tmp2 = []<any>(tmp[1])
		} else {
			tmp2 = [](any(tmp[1]))
		}
ot = (ObjectType) tmp2[0]
		ln := helpers.ToLogicalName(tmp2[1])
		if ot != enums.ObjectTypeNone {
			if g.parent != nil {
				charge.Commodity.g.Target()
				// If object is not found from the association view.
				if charge.Commodity.g.Target == nil {
					// TODO: MIKKO: FAILED
					// charge.Commodity.Target = GXDLMSClient.CreateObject(ot);
					// Menetelmää tai toimintoa ei ole toteutettu.
					// TODO: MIKKO: FAILED
					// charge.Commodity.Target.LogicalName = ln;
					// Method not implemented. GXUnitCharge.Commodity.Target
				}
			} else {
				// TODO: MIKKO: FAILED
				// charge.Commodity.Target = GXDLMSClient.CreateObject(ot);
				// Menetelmää tai toimintoa ei ole toteutettu.
				// TODO: MIKKO: FAILED
				// charge.Commodity.Target.LogicalName = ln;
				// Method not implemented. GXUnitCharge.Commodity.Target
			}
		} else {
			charge.Commodity.g.Target(nil)
		}
		charge.Commodity.g.Index(int8(tmp2[2]))
		list := []GXChargeTable[objects.GXChargeTable){}
		for _, tmp3 := range IEnumerable<any>(tmp[2]) {
if _, ok := tmp3.(List[any]); ok {
				it = []<any>(tmp3)
			} else {
				it = [](any(tmp3))
			}
			item := GXChargeTable{}
			item.g.Index(it[0].(uint8[]).(string))
			item.g.ChargePerUnit(int16(it[1]))
			list = append(list, item)
		}
		charge.g.ChargeTables(list)
	} else {
		charge.ChargePerUnitScaling.g.CommodityScale(0)
		charge.ChargePerUnitScaling.g.PriceScale(0)
		charge.Commodity.g.Target(nil)
		charge.Commodity.g.Index(0)
		charge.g.ChargeTables(make([]GXChargeTable, {}))
	}
}

//SetValue returns the set value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Set parameters.
func (g *GXDLMSCharge) SetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs)error {
	switch (e.Index) {
	case 1:
		g.LogicalName = helpers.ToLogicalName(e.Value)
	case 2:
		g.TotalAmountPaid = int32(e.Value)
	case 3:
		 = ChargeType(e.Value.(types.GXEnum).Value)
	case 4:
		 = uint8(e.Value)
	case 5:
g.SetUnitCharge(g.UnitChargeActive, e.Value)	case 6:
g.SetUnitCharge(g.UnitChargePassive, e.Value)	case 7:
if _, ok := e.Value.(GXDateTime); ok {
			g.UnitChargeActivationTime = GXDateTime(e.Value)
		} else if _, ok := e.Value.([]byte); ok {
			g.UnitChargeActivationTime = GXDateTime(GXDLMSClient.ChangeType([]byte(e.Value), enums.DataTypeDateTime, settings != nil && settings.UseUtc2NormalTime()))
		} else if _, ok := e.Value.(string); ok {
			g.UnitChargeActivationTime = GXDateTime(string(e.Value))
		} else {
			g.UnitChargeActivationTime = nil
		}
	case 8:
		g.Period = uint32(e.Value)
	case 9:
		 = ChargeConfiguration(e.v.Value)
	case 10:
if _, ok := e.Value.(GXDateTime); ok {
			g.LastCollectionTime = GXDateTime(e.Value)
		} else if _, ok := e.Value.(time.Time); ok {
			g.LastCollectionTime = time.Time(e.Value)
		} else if _, ok := e.Value.([]byte); ok {
			g.LastCollectionTime = GXDateTime(GXDLMSClient.ChangeType([]byte(e.Value), enums.DataTypeDateTime, settings != nil && settings.UseUtc2NormalTime()))
		} else if _, ok := e.Value.(string); ok {
			g.LastCollectionTime = GXDateTime(e.Value.(string))
		} else {
			g.LastCollectionTime = nil
		}
	case 11:
		g.LastCollectionAmount = int32(e.Value)
	case 12:
		g.TotalAmountRemaining = int32(e.Value)
	case 13:
		g.Proportion, err = uint16(e.Value)
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
}

// TODO: Comment is missing.
func (g *GXDLMSCharge) LoadUnitChargeActive(reader *GXXmlReader, name string, charge *GXUnitCh errorarge) {
	if reader.IsStartElement(name, true) {
		charge.ChargePerUnitScaling.g.CommodityScale(int8(reader.ReadElementContentAsInt("Scale")		
		if err !, err= nil {
			return err
		}))
		charge.ChargePerUnitScaling.g.PriceScale(int8(reader.ReadElementContentAsInt("PriceScale")		
		if err != nil {
			return err
		}))
ot, err = (ObjectType) reader.ReadElementContentAsInt("Type")		
		if err != nil {
			return err
		}
		ln :, err= reader.ReadElementContentAsString("Ln")
		charge.Commodity.g.Target(.FindByLN(ot, ln))
		charge.Commodity.g.Index(reader.ReadElementContentAsInt("Index")		
		if err != nil {
			return err
		})
		list := []GXChargeTable[objects.GXChargeTable){}
		if reader.IsStartElement("ChargeTables", true) {
for(reader.IsStartElement("Item", true)) {
				it :, err= GXChargeTable{}
				it.g.Index(reader.ReadElementContentAsString("Index")				
				if err !, err= nil {
					return err
				})
				it.g.ChargePerUnit(short(reader.ReadElementContentAsInt("ChargePerUnit")				
				if err != nil {
					return err
				}))
				list = append(list, it)
			}
			reader.ReadEndElement("ChargeTables")
		}
		reader.ReadEndElement(name)
		charge.g.ChargeTables(list)
	}
return err
}

//Load returns the load object content from XML.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSCharge) Load(reader *GXXmlReader) error {
	var err error
	g.TotalAmountPaid, err = reader.ReadElementContentAsInt("TotalAmountPaid")	
	if err != nil {
		return err
	}
	ChargeType, err = ChargeType(reader.ReadElementContentAsInt("ChargeType")	
	if err != nil {
		return err
	})
	Priority, err = uint8(reader.ReadElementContentAsInt("Priority")	
	if err != nil {
		return err
	})
	g.LoadUnitChargeActive(reader, "UnitChargeActive", g.UnitChargeActive)
	g.LoadUnitChargeActive(reader, "UnitChargePassive", g.UnitChargePassive)
	tmp := reader.ReadElementContentAsString("UnitChargeActivationTime")
	if tmp != nil {
		// TODO: MIKKO: FAILED
		// UnitChargeActivationTime = new GXDateTime(tmp, System.Globalization.CultureInfo.InvariantCulture);
		// System.Globalization.CultureInfo.InvariantCulture
	}
	g.Period, err = uint16(reader.ReadElementContentAsInt("Period")	
	if err != nil {
		return err
	})
	ChargeConfiguration, err = ChargeConfiguration(reader.ReadElementContentAsInt("ChargeConfiguration")	
	if err != nil {
		return err
	})
	tmp, err = reader.ReadElementContentAsString("LastCollectionTime")	
	if err != nil {
		return err
	}
	if tmp != nil {
		// TODO: MIKKO: FAILED
		// LastCollectionTime = new GXDateTime(tmp, System.Globalization.CultureInfo.InvariantCulture);
		// System.Globalization.CultureInfo.InvariantCulture
	}
	g.LastCollectionAmount, err = reader.ReadElementContentAsInt("LastCollectionAmount")	
	if err != nil {
		return err
	}
	g.TotalAmountRemaining, err = reader.ReadElementContentAsInt("TotalAmountRemaining")	
	if err != nil {
		return err
	}
	g.Proportion, err = uint16(reader.ReadElementContentAsInt("Proportion")	
	if err != nil {
		return err
	})
return err
}

// TODO: Comment is missing.
func (g *GXDLMSCharge) SaveUnitCharge(writer *GXXmlWriter, name string, charge *GXUnitCharge) error {
	writer.WriteStartElement(name)
	err = writer.WriteElementString("Scale", charge.ChargePerUnitScaling.g.CommodityScale)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("PriceScale", charge.ChargePerUnitScaling.g.PriceScale)	
	if err != nil {
		return err
	}
	if charge.Commodity.g.Target != nil {
		// TODO: MIKKO: FAILED
		// writer.WriteElementString("Type", (int)charge.Commodity.Target.ObjectType);
		// Method not implemented. GXUnitCharge.Commodity.Target
		// TODO: MIKKO: FAILED
		// writer.WriteElementString("Ln", charge.Commodity.Target.LogicalName);
		// Method not implemented. GXUnitCharge.Commodity.Target
	} else {
		err = writer.WriteElementString("Type", 0)		
		if err != nil {
			return err
		}
		err = writer.WriteElementString("Ln", "0.0.0.0.0.0")		
		if err != nil {
			return err
		}
	}
	err = writer.WriteElementString("Index", charge.Commodity.g.Index)	
	if err != nil {
		return err
	}
	writer.WriteStartElement("ChargeTables")
	if charge.ChargeTables() != nil {
		for _, it := range charge.ChargeTables() {
			writer.WriteStartElement("Item")
			err = writer.WriteElementString("Index", it.Index())			
			if err != nil {
				return err
			}
			err = writer.WriteElementString("ChargePerUnit", it.ChargePerUnit())			
			if err != nil {
				return err
			}
			writer.WriteEndElement()
		}
	}
	writer.WriteEndElement()
	writer.WriteEndElement()
return err
}

//Save returns the save object content to XML.
//
// Parameters:
//   writer: XML writer.
func (g *GXDLMSCharge) Save(writer *GXXmlWriter) error {
	err = writer.WriteElementString("TotalAmountPaid", g.TotalAmountPaid)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("ChargeType", int())	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("Priority", )	
	if err != nil {
		return err
	}
	g.SaveUnitCharge(writer, "UnitChargeActive", g.UnitChargeActive)
	g.SaveUnitCharge(writer, "UnitChargePassive", g.UnitChargePassive)
	err = writer.WriteElementString("UnitChargeActivationTime", g.UnitChargeActivationTime)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("Period", g.Period)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("ChargeConfiguration", int())	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("LastCollectionTime", g.LastCollectionTime)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("LastCollectionAmount", g.LastCollectionAmount)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("TotalAmountRemaining", g.TotalAmountRemaining)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("Proportion", g.Proportion)	
	if err != nil {
		return err
	}
return err
}

//PostLoad returns the handle actions after Load.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSCharge) PostLoad(reader *GXXmlReader) {
}


//GetValues returns the an array containing the COSEM object's attribute values.
func (g *GXDLMSCharge) GetValues() []any {
	return []any{g.LogicalName, g.TotalAmountPaid, , , g.UnitChargeActive, g.UnitChargePassive, g.UnitChargeActivationTime, g.Period, , g.LastCollectionTime, g.LastCollectionAmount, g.TotalAmountRemaining, g.Proportion}
}

//GetDataType returns the device data type of selected attribute index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   Device data type of the object.
func (g *GXDLMSCharge) GetDataType(index int) errorenums.DataType {
	switch (index) {
	case 1:
		return enums.DataTypeOctetString
	case 2:
		return enums.DataTypeInt32
	case 3:
		return enums.DataTypeEnum
	case 4:
		return enums.DataTypeUInt8
	case 5:
		return enums.DataTypeStructure
	case 6:
		return enums.DataTypeStructure
	case 7:
		return enums.DataTypeOctetString
	case 8:
		return enums.DataTypeUInt32
	case 9:
		return enums.DataTypeBitString
	case 10:
		return enums.DataTypeDateTime
	case 11:
		return enums.DataTypeInt32
	case 12:
		return enums.DataTypeInt32
	case 13:
		return enums.DataTypeUInt16
	default:
		return errors.New("GetDataType failed. Invalid attribute index.")
	}
}

//GetUIDataType returns the UI data type of selected index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   UI data type of the object.
func (g *GXDLMSCharge) GetUIDataType(index int) enums.DataType {
	if index == 7 || index == 10 {
		return enums.DataTypeDateTime
	}
	return 
}



// NewGXDLMSGXDLMSCharge creates a new Charge object instance.
//
// The function validates `ln` before creating the object.
//`ln` is the Logical Name and `sn` is the Short Name of the object.
func NewGXDLMSCharge(ln string, sn int16) (*GXDLMSCharge, error) {
	err := ValidateLogicalName(ln)
	if err != nil {
		return nil, err
	}
	return &GXDLMSCharge {
		GXDLMSObject: GXDLMSObject{
			objectType:  enums.ObjectTypeCharge,
			logicalName: ln,
			ShortName:   sn,
		},
	}, nil
}

