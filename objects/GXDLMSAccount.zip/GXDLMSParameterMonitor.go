﻿package objects

//
// --------------------------------------------------------------------------
//  Gurux Ltd
//
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// More information of Gurux products: https://www.gurux.org
//
// This code is licensed under the GNU General Public License v2.
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

import (
	"fmt"
	"gurux.dlms"
	"github.com/Gurux/gxdlms-go/enums"
	"time"
)

// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSParameterMonitor
type GXDLMSParameterMonitor struct {
	GXDLMSObject
	// Changed parameter.
	ChangedParameter GXDLMSTarget

	// Capture time.
	CaptureTime time.time.Time

	// Changed Parameter
	Parameters []
}
// Base returns the base GXDLMSObject of the object.
func (g *GXDLMSParameterMonitor) Base() *GXDLMSObject {
	return &g.GXDLMSObject
}

//Invoke returns the invokes method.
//
// Parameters:
//   settings: DLMS settings.
//   e: Invoke parameters.
func (g *GXDLMSParameterMonitor) Invoke(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs)  ([]byte, error)  {
	if e.Index != 1 && e.Index != 2 {
		e.Error = enums.ErrorCodeReadWriteDenied
	} else {
if e.Index == 1 {
tmp = ([]<any>) e.Parameters()
type = (ObjectType) uint16(tmp[0])
			ln := helpers.ToLogicalName([]byte(tmp[1]))
			index := Convert.ToByte(tmp[2])
			for _, item := range g.Parameters {
if item.Target.G.objectType == type && item.Target.g.LogicalName == ln && item.AttributeIndex() == index {
					// TODO: MIKKO: FAILED
					// Parameters.Remove(item);
					// Unknown method data type List.Remove
					break;
				}
			}
			it := GXDLMSTarget{}
			it.g.Target(.FindByLN(type, []byte(tmp[1])))
if it.Target() == nil {
				// TODO: MIKKO: FAILED
				// it.Target = GXDLMSClient.CreateObject(type);
				// Menetelmää tai toimintoa ei ole toteutettu.
				it.Target.g.LogicalName(ln)
			}
			it.g.AttributeIndex(index)
			g.Parameters = append(g.Parameters, it)
		} else if e.Index == 2 {
tmp = ([]<any>) e.Parameters()
ot = (ObjectType) uint16(tmp[0])
			ln := helpers.ToLogicalName([]byte(tmp[1]))
			index := Convert.ToByte(tmp[2])
			for _, item := range g.Parameters {
if item.Target.G.objectType == ot && item.Target.g.LogicalName == ln && item.AttributeIndex() == index {
					// TODO: MIKKO: FAILED
					// Parameters.Remove(item);
					// Unknown method data type List.Remove
					break;
				}
			}
		}
	}
	return nil
}

//GetAttributeIndexToRead returns the collection of attributes to read.
// If attribute is static and already read or device is returned HW error it is not returned.
//
// Parameters:
//   all: All items are returned even if they are read already.
//
// Returns:
//   Collection of attributes to read.
func (g *GXDLMSParameterMonitor) GetAttributeIndexToRead(all bool) []int {
	var attributes []int
	// LN is static and read only once.
	if all || g.LogicalName() == "" {
		attributes = append(attributes, 1)
	}
	// ChangedParameter
	if all || g.CanRead(2) {
		attributes = append(attributes, 2)
	}
	// CaptureTime
	if all || g.CanRead(3) {
		attributes = append(attributes, 3)
	}
	// Parameters
	if all || g.CanRead(4) {
		attributes = append(attributes, 4)
	}
	return attributes
}

//GetNames returns the names of attribute indexes.
func (g *GXDLMSParameterMonitor) GetNames() []string {
	return []string{"Logical Name", "ChangedParameter", "CaptureTime", "Parameters"}
}

//GetMethodNames returns the names of method indexes.
func (g *GXDLMSParameterMonitor) GetMethodNames() []string {
	return []string{"Add parameter", "Delete parameter"}
}

//GetAttributeCount returns the amount of attributes.
//
// Returns:
//   Count of attributes.
func (g *GXDLMSParameterMonitor) GetAttributeCount() int {
	return 4
}

//GetMethodCount returns the amount of methods.
func (g *GXDLMSParameterMonitor) GetMethodCount() int {
	return 2
}

//GetValue returns the value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Get parameters.
//
// Returns:
//   Value of the attribute index.
func (g *GXDLMSParameterMonitor) GetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) (any, error) {
	switch (e.Index) {
	case 1:
		return GXCommon.LogicalNameToBytes(g.LogicalName)
	case 2:
 {
			data := GXByteBuffer{}
err = data.SetUInt8(uint8(enums.DataTypeStructure))			
			if err != nil {
				return err
			}err = data.SetUInt8(4)			
			if err != nil {
				return err
			}			if g.ChangedParameter == nil || g.ChangedParameter.Target == nil {
GXCommon.SetData(settings, data, enums.DataTypeUInt16, 0)GXCommon.SetData(settings, data, enums.DataTypeOctetString, make([]byte, ){0, 0, 0, 0, 0, 0})GXCommon.SetData(settings, data, enums.DataTypeInt8, 1)GXCommon.SetData(settings, data, enums.DataTypeNone, nil)			} else {
				GXCommon.SetData(settings, data, enums.DataTypeUInt16, ChangedParameter.Target.G.objectType)
				GXCommon.SetData(settings, data, enums.DataTypeOctetString, GXCommon.LogicalNameToBytes(ChangedParameter.Target.g.LogicalName))
				GXCommon.SetData(settings, data, enums.DataTypeInt8, g.ChangedParameter.AttributeIndex)
				GXCommon.SetData(settings, data, GXDLMSConverter.GetDLMSDataType(g.ChangedParameter.Value), g.ChangedParameter.Value)
			}
			return data.Array(), nil
		}
	case 3:
		return g.CaptureTime, nil
	case 4:
 {
			data := GXByteBuffer{}
err = data.SetUInt8(uint8(enums.DataTypeArray))			
			if err != nil {
				return err
			}			if g.Parameters == nil {
err = data.SetUInt8(0)				
				if err != nil {
					return err
				}			} else {
				err = data.SetUInt8(uint8(len(g.Parameters)))				
				if err != nil {
					return err
				}
				for _, it := range g.Parameters {
					err = data.SetUInt8(uint8(enums.DataTypeStructure))					
					if err != nil {
						return err
					}
					err = data.SetUInt8(uint8(3))					
					if err != nil {
						return err
					}
					GXCommon.SetData(settings, data, enums.DataTypeUInt16, it.Target.G.objectType)
					GXCommon.SetData(settings, data, enums.DataTypeOctetString, GXCommon.LogicalNameToBytes(it.Target.g.LogicalName))
					GXCommon.SetData(settings, data, enums.DataTypeInt8, it.AttributeIndex())
				}
			}
			return data.Array(), nil
		}
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
	return nil, nil
return err
}

//SetValue returns the set value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Set parameters.
func (g *GXDLMSParameterMonitor) SetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs)error {
	switch (e.Index) {
	case 1:
		g.LogicalName = helpers.ToLogicalName(e.Value)
	case 2:
 {
			// TODO: MIKKO: FAILED
			// ChangedParameter = new GXDLMSTarget();
			// Unknown exception type
tmp := nil
if _, ok := e.Value.(List[any]); ok {
				tmp = []<any>(e.Value)
			} else if _, ok := e.Value.(any); ok {
				tmp = [](any(e.Value))
			}
			if tmp != nil {
				if len(tmp) != 4 {
					return 0, GXDLMSException("Invalid structure format.")
				}
type = (ObjectType) int16(tmp[0])
				ChangedParameter.Target(.FindByLN(type, []byte(tmp[1])))
				if g.ChangedParameter.Target == nil {
					// TODO: MIKKO: FAILED
					// ChangedParameter.Target = GXDLMSClient.CreateObject(type);
					// Menetelmää tai toimintoa ei ole toteutettu.
					ChangedParameter.Target.g.LogicalName(helpers.ToLogicalName([]byte(tmp[1])))
				}
				ChangedParameter.AttributeIndex(Convert.ToByte(tmp[2]))
				ChangedParameter.Value(tmp[3])
			}
		}
	case 3:
 {
			if e.Value == nil {
				g.CaptureTime = GXDateTime(MinValue)
			} else {
if _, ok := e.Value.([]byte); ok {
					e.v.Value(GXDLMSClient.ChangeType([]byte(e.Value), enums.DataTypeDateTime, settings.UseUtc2NormalTime()))
				} else if _, ok := e.Value.(string); ok {
					e.v.Value(GXDateTime(string(e.Value)))
				}
if _, ok := e.Value.(GXDateTime); ok {
					g.CaptureTime = GXDateTime(e.Value)
				} else if _, ok := e.Value.(string); ok {
					var tm time.Time
if _, ok := e.Value.(string); ok {
						// TODO: MIKKO: FAILED
						// CaptureTime = DateTime.ParseExact((String)e.Value, CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern + " " + CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern, CultureInfo.CurrentUICulture);
						// Menetelmää tai toimintoa ei ole toteutettu.
					} else {
						g.CaptureTime = tm
					}
				} else {
					g.CaptureTime = Convert.ToDateTime(e.Value)
				}
			}
		}
	case 4:
 {
			// TODO: MIKKO: FAILED
			// Parameters.Clear();
			// Unknown method data type List.Clear
			if e.Value != nil {
				for _, it := range e.Value.(IEnumerable[any]) {
					var tmp []
if _, ok := it.(List[any]); ok {
						tmp = []<any>(it)
					} else {
						tmp = [](any(it))
					}
					if len(tmp) != 3 {
						return 0, GXDLMSException("Invalid structure format.")
					}
					obj := GXDLMSTarget{}
type = (ObjectType) int16(tmp[0])
					obj.g.Target(.FindByLN(type, []byte(tmp[1])))
					if obj.Target() == nil {
						// TODO: MIKKO: FAILED
						// obj.Target = GXDLMSClient.CreateObject(type);
						// Menetelmää tai toimintoa ei ole toteutettu.
						obj.Target.g.LogicalName(helpers.ToLogicalName([]byte(tmp[1])))
					}
					obj.g.AttributeIndex(Convert.ToByte(tmp[2]))
g.Parameters = append(g.Parameters, obj)				}
			}
		}
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
}

//Load returns the load object content from XML.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSParameterMonitor) Load(reader *GXXmlReader) error {
	var err error
	// TODO: MIKKO: FAILED
	// ChangedParameter = new GXDLMSTarget();
	// Unknown exception type
	if reader.IsStartElement("ChangedParameter", true) {
ot, err = (ObjectType) reader.ReadElementContentAsInt("Type")		
		if err != nil {
			return err
		}
		ln := reader.ReadElementContentAsString("LN")
		ChangedParameter.Target(.FindByLN(ot, ln))
		if g.ChangedParameter.Target == nil {
			// TODO: MIKKO: FAILED
			// ChangedParameter.Target, err = GXDLMSClient.CreateObject(ot);
			// Menetelmää tai toimintoa ei ole toteutettu.
			ChangedParameter.Target.g.LogicalName(ln)
		}
		ChangedParameter.AttributeIndex(uint8(reader.ReadElementContentAsInt("Index")		
		if err !, err= nil {
			return err
		}))
		ChangedParameter.Value(reader.ReadElementContentAsObject("Value", nil, nil, 0)		
		if err != nil {
			return err
		})
		reader.ReadEndElement("ChangedParameter")
	}
	if strings.EqualFold("Time",reader.g.name) {
		g.CaptureTime, err = GXDateTime(reader.ReadElementContentAsString("Time")		
		if err != nil {
			return err
		}, InvariantCulture)
	} else {
		g.CaptureTime = MinValue
	}
	// TODO: MIKKO: FAILED
	// Parameters.Clear();
	// Unknown method data type List.Clear
	if reader.IsStartElement("Parameters", true) {
for(reader.IsStartElement("Item", true)) {
			obj := GXDLMSTarget{}
ot, err = (ObjectType) reader.ReadElementContentAsInt("Type")			
			if err != nil {
				return err
			}
			ln := reader.ReadElementContentAsString("LN")
			obj.g.Target(.FindByLN(ot, ln))
			if obj.Target() == nil {
				// TODO: MIKKO: FAILED
				// obj.Target, err = GXDLMSClient.CreateObject(ot);
				// Menetelmää tai toimintoa ei ole toteutettu.
				obj.Target.g.LogicalName(ln)
			}
			obj.g.AttributeIndex(uint8(reader.ReadElementContentAsInt("Index")			
			if err != nil {
				return err
			}))
			g.Parameters = append(g.Parameters, obj)
		}
		reader.ReadEndElement("Parameters")
	}
return err
}

//Save returns the save object content to XML.
//
// Parameters:
//   writer: XML writer.
func (g *GXDLMSParameterMonitor) Save(writer *GXXmlWriter) error {
	writer.WriteStartElement("ChangedParameter")
	if g.ChangedParameter != nil && g.ChangedParameter.Target != nil {
		err = writer.WriteElementString("Type", int(ChangedParameter.Target.G.objectType))		
		if err != nil {
			return err
		}
		err = writer.WriteElementString("LN", ChangedParameter.Target.g.LogicalName)		
		if err != nil {
			return err
		}
		err = writer.WriteElementString("Index", g.ChangedParameter.AttributeIndex)		
		if err != nil {
			return err
		}
		err = writer.WriteElementObject("Value", g.ChangedParameter.Value)		
		if err != nil {
			return err
		}
	}
	writer.WriteEndElement()
	err = writer.WriteElementString("Time", g.CaptureTime)	
	if err != nil {
		return err
	}
	writer.WriteStartElement("Parameters")
	if g.Parameters != nil && len(g.Parameters) != 0 {
		for _, it := range g.Parameters {
			writer.WriteStartElement("Item")
			err = writer.WriteElementString("Type", int(it.Target.G.objectType))			
			if err != nil {
				return err
			}
			err = writer.WriteElementString("LN", it.Target.g.LogicalName)			
			if err != nil {
				return err
			}
			err = writer.WriteElementString("Index", it.AttributeIndex())			
			if err != nil {
				return err
			}
			writer.WriteEndElement()
		}
	}
	writer.WriteEndElement()
return err
}

//PostLoad returns the handle actions after Load.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSParameterMonitor) PostLoad(reader *GXXmlReader) {
}


//GetValues returns the an array containing the COSEM object's attribute values.
func (g *GXDLMSParameterMonitor) GetValues() []any {
	return []any{g.LogicalName, g.ChangedParameter, g.CaptureTime, g.Parameters}
}

//Insert returns the inserts a new entry in the table.
func (g *GXDLMSParameterMonitor) Insert(client *IGXDLMSClient, entry *GXDLMSTarget) ([][]uint8, error) {
	bb := GXByteBuffer{}
	err = bb.SetUInt8(enums.DataTypeStructure)	
	if err != nil {
		return err
	}
	err = bb.SetUInt8(3)	
	if err != nil {
		return err
	}
	GXCommon.SetData(nil, bb, enums.DataTypeUInt16, entry.Target.G.objectType)
	GXCommon.SetData(nil, bb, enums.DataTypeOctetString, GXCommon.LogicalNameToBytes(entry.Target.g.LogicalName))
	GXCommon.SetData(nil, bb, enums.DataTypeInt8, entry.AttributeIndex())
	return client.Method(g, 1, bb.Array(), enums.DataTypeArray), nil
return err
}

//Delete returns the deletes an entry from the table.
func (g *GXDLMSParameterMonitor) Delete(client *IGXDLMSClient, entry *GXDLMSTarget) ([][]uint8, error) {
	bb := GXByteBuffer{}
	err = bb.SetUInt8(enums.DataTypeStructure)	
	if err != nil {
		return err
	}
	err = bb.SetUInt8(3)	
	if err != nil {
		return err
	}
	GXCommon.SetData(nil, bb, enums.DataTypeUInt16, entry.Target.G.objectType)
	GXCommon.SetData(nil, bb, enums.DataTypeOctetString, GXCommon.LogicalNameToBytes(entry.Target.g.LogicalName))
	GXCommon.SetData(nil, bb, enums.DataTypeInt8, entry.AttributeIndex())
	return client.Method(g, 2, bb.Array(), enums.DataTypeArray), nil
return err
}

//GetDataType returns the device data type of selected attribute index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   Device data type of the object.
func (g *GXDLMSParameterMonitor) GetDataType(index int) errorenums.DataType {
	switch (index) {
	case 1:
		return enums.DataTypeOctetString
	case 2:
		return enums.DataTypeStructure
	case 3:
		return enums.DataTypeOctetString
	case 4:
		return enums.DataTypeArray
	default:
		return errors.New("GetDataType failed. Invalid attribute index.")
	}
}



// NewGXDLMSGXDLMSParameterMonitor creates a new Parameter Monitor object instance.
//
// The function validates `ln` before creating the object.
//`ln` is the Logical Name and `sn` is the Short Name of the object.
func NewGXDLMSParameterMonitor(ln string, sn int16) (*GXDLMSParameterMonitor, error) {
	err := ValidateLogicalName(ln)
	if err != nil {
		return nil, err
	}
	return &GXDLMSParameterMonitor {
		GXDLMSObject: GXDLMSObject{
			objectType:  enums.ObjectTypeParameterMonitor,
			logicalName: ln,
			ShortName:   sn,
		},
	}, nil
}

