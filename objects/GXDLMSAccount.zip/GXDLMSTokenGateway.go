﻿package objects

//
// --------------------------------------------------------------------------
//  Gurux Ltd
//
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// More information of Gurux products: https://www.gurux.org
//
// This code is licensed under the GNU General Public License v2.
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

import (
	"fmt"
	"gurux.dlms"
	"github.com/Gurux/gxdlms-go/enums" 
)

// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSTokenGateway
type GXDLMSTokenGateway struct {
	GXDLMSObject
	// Token.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSTokenGateway
	Token []byte

	// Time
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSTokenGateway
	Time dlms.GXDateTime

	// Descriptions.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSTokenGateway
	Descriptions []

	// Token Delivery method.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSTokenGateway
	DeliveryMethod TokenDelivery

	// Token status code.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSTokenGateway
	StatusCode TokenStatusCode

	// Token data value.
// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSTokenGateway
	DataValue string

// Base returns the base GXDLMSObject of the object.
func (g *GXDLMSTokenGateway) Base() *GXDLMSObject {
	return &g.GXDLMSObject
}

//Invoke returns the invokes method.
//
// Parameters:
//   settings: DLMS settings.
//   e: Invoke parameters.
func (g *GXDLMSTokenGateway) Invoke(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs)  ([]byte, error) {
	e.Error = enums.ErrorCodeReadWriteDenied
	return nil
}

//GetAttributeIndexToRead returns the collection of attributes to read.
// If attribute is static and already read or device is returned HW error it is not returned.
//
// Parameters:
//   all: All items are returned even if they are read already.
//
// Returns:
//   Collection of attributes to read.
func (g *GXDLMSTokenGateway) GetAttributeIndexToRead(all bool) []int {
	var attributes []int
	// LN is static and read only once.
	if all || g.LogicalName() == "" {
		attributes = append(attributes, 1)
	}
	// Token
	if all || g.CanRead(2) {
		attributes = append(attributes, 2)
	}
	// Time
	if all || g.CanRead(3) {
		attributes = append(attributes, 3)
	}
	// Description
	if all || g.CanRead(4) {
		attributes = append(attributes, 4)
	}
	// DeliveryMethod
	if all || g.CanRead(5) {
		attributes = append(attributes, 5)
	}
	// Status
	if all || g.CanRead(6) {
		attributes = append(attributes, 6)
	}
	return attributes
}

//GetNames returns the names of attribute indexes.
func (g *GXDLMSTokenGateway) GetNames() []string {
	return []string{"Logical Name", "Token", "Time", "Description", "DeliveryMethod", "Status"}
}

//GetMethodNames returns the names of method indexes.
func (g *GXDLMSTokenGateway) GetMethodNames() []string {
	return []string{"Enter"}
}

//GetAttributeCount returns the amount of attributes.
//
// Returns:
//   Count of attributes.
func (g *GXDLMSTokenGateway) GetAttributeCount() int {
	return 6
}

//GetMethodCount returns the amount of methods.
func (g *GXDLMSTokenGateway) GetMethodCount() int {
	return 1
}

//GetValue returns the value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Get parameters.
//
// Returns:
//   Value of the attribute index.
func (g *GXDLMSTokenGateway) GetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) (any, error) {
	var bb GXByteBuffer
		// TODO: MIKKO: FAILED
		// switch (e.Index)
		// {
		// case 1:
		// return GXCommon.LogicalNameToBytes(LogicalName);
		// case 2:
		// return Token;
		// case 3:
		// return Time;
		// case 4:
		// bb = new GXByteBuffer();
		// bb.SetUInt8(DataType.Array);
		// if (Descriptions == nil)
		// {
		// bb.SetUInt8(0);
		// }
		// else
		// {
		// bb.SetUInt8((byte)Descriptions.Count);
		// foreach (string it in Descriptions)
		// {
		// bb.SetUInt8(DataType.OctetString);
		// bb.SetUInt8((byte)it.Length);
		// bb.Set(ASCIIEncoding.ASCII.GetBytes(it));
		// }
		// }
		// return bb.Array();
		// case 5:
		// return DeliveryMethod;
		// case 6:
		// bb = new GXByteBuffer();
		// bb.SetUInt8(DataType.Structure);
		// bb.SetUInt8(2);
		// GXCommon.SetData(settings, bb, DataType.Enum, StatusCode);
		// GXCommon.SetData(settings, bb, DataType.BitString, DataValue);
		// return bb.Array();
		// default:
		// e.Error = ErrorCode.ReadWriteDenied;
		// break;
		// }
		// Unknown exception type
		return nil
	}

	//SetValue returns the set value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Set parameters.
func (g *GXDLMSTokenGateway) SetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) error{
			// TODO: MIKKO: FAILED
			// switch (e.Index)
			// {
			// case 1:
			// LogicalName = helpers.ToLogicalName(e.Value);
			// break;
			// case 2:
			// Token = (byte[])e.Value;
			// break;
			// case 3:
			// if (e.Value is byte[])
			// {
			// Time = (GXDateTime)GXDLMSClient.ChangeType((byte[])e.Value, DataType.DateTime, settings != nil && settings.UseUtc2NormalTime);
			// }
			// else if (e.Value is string)
			// {
			// Time = new GXDateTime((string)e.Value);
			// }
			// else
			// {
			// Time = (GXDateTime)e.Value;
			// }
			// break;
			// case 4:
			// Descriptions.Clear();
			// if (e.Value != nil)
			// {
			// foreach (object it in (IEnumerable<object>)e.Value)
			// {
			// Descriptions.Add(ASCIIEncoding.ASCII.GetString((byte[])it));
			// }
			// }
			// break;
			// case 5:
			// DeliveryMethod = (TokenDelivery)e.Value.(types.GXEnum).Value;
			// break;
			// case 6:
			// if (e.Value != nil)
			// {
			// List<object> arr;
			// if (e.Value is List<object>)
			// {
			// arr = (List<object>)e.Value;
			// }
			// else
			// {
			// arr = new List<object>((object[])e.Value);
			// }
			// StatusCode = (TokenStatusCode)Convert.ToInt32(arr[0]);
			// DataValue = Convert.ToString(arr[1]);
			// }
			// else
			// {
			// StatusCode = TokenStatusCode.FormatOk;
			// DataValue = "";
			// }
			// break;
			// default:
			// e.Error = ErrorCode.ReadWriteDenied;
			// break;
			// }
			// Unknown method data type List.Clear
		}

		//Load returns the load object content from XML.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSTokenGateway) Load(reader *GXXmlReader) error {
	var err error		
	g.Token, err = GXCommon.HexToBytes(reader.ReadElementContentAsString("Token")			
			if err != nil {
				return err
			})
			tmp := reader.ReadElementContentAsString("Time")
			if tmp != nil {
				// TODO: MIKKO: FAILED
				// Time = new GXDateTime(tmp, System.Globalization.CultureInfo.InvariantCulture);
				// System.Globalization.CultureInfo.InvariantCulture
			}
			// TODO: MIKKO: FAILED
			// Descriptions.Clear();
			// Unknown method data type List.Clear
			if reader.IsStartElement("Descriptions", true) {
for(reader.IsStartElement("Item", true)) {
					g.Descriptions = append(g.Descriptions, reader.ReadElementContentAsString("Name"))
				}
				reader.ReadEndElement("Descriptions")
			}
			g.DeliveryMethod, err = TokenDelivery(reader.ReadElementContentAsInt("DeliveryMethod")			
			if err != nil {
				return err
			})
			g.StatusCode, err = TokenStatusCode(reader.ReadElementContentAsInt("Status")			
			if err != nil {
				return err
			})
			g.DataValue, err = reader.ReadElementContentAsString("Data")			
			if err != nil {
				return err
			}		
		return err		
		}

		//Save returns the save object content to XML.
//
// Parameters:
//   writer: XML writer.
func (g *GXDLMSTokenGateway) Save(writer *GXXmlWriter) error {
			err = writer.WriteElementString("Token", GXCommon.ToHex(g.Token, false))			
			if err != nil {
				return err
			}
			err = writer.WriteElementString("Time", g.Time)			
			if err != nil {
				return err
			}
			writer.WriteStartElement("Descriptions")
			if g.Descriptions != nil {
				for _, it := range g.Descriptions {
					writer.WriteStartElement("Item")
					err = writer.WriteElementString("Name", it)					
					if err != nil {
						return err
					}
					writer.WriteEndElement()
				}
			}
			writer.WriteEndElement()
			err = writer.WriteElementString("DeliveryMethod", int(g.DeliveryMethod))			
			if err != nil {
				return err
			}
			err = writer.WriteElementString("Status", int(g.StatusCode))			
			if err != nil {
				return err
			}
			err = writer.WriteElementString("Data", g.DataValue)			
			if err != nil {
				return err
			}		
		return err		
		}

		//PostLoad returns the handle actions after Load.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSTokenGateway) PostLoad(reader *GXXmlReader) {
		}
	

//GetValues returns the an array containing the COSEM object's attribute values.
func (g *GXDLMSTokenGateway) GetValues() []any {
	return []any{g.LogicalName, g.Token, g.Time, g.Descriptions, g.DeliveryMethod, []any{g.StatusCode, g.DataValue}}
}

//Enter returns the transfer a token to the server.
//
// Parameters:
//   client: DLMS client.
//   token: The token to send.
//
// Returns:
//   Action bytes.
func (g *GXDLMSTokenGateway) Enter(client *IGXDLMSClient, token []byte) [][]uint8 {
	return client.Method(g, 1, token, enums.DataTypeOctetString)
}

//GetUIDataType returns the UI data type of selected index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   UI data type of the object.
func (g *GXDLMSTokenGateway) GetUIDataType(index int) enums.DataType {
	if index == 3 {
		return enums.DataTypeDateTime
	}
	return 
}

//GetDataType returns the device data type of selected attribute index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   Device data type of the object.
func (g *GXDLMSTokenGateway) GetDataType(index int) errorenums.DataType {
	switch (index) {
	case 1:
		return enums.DataTypeOctetString
	case 2:
		return enums.DataTypeOctetString
	case 3:
		return enums.DataTypeOctetString
	case 4:
		return enums.DataTypeArray
	case 5:
		return enums.DataTypeEnum
	case 6:
		return enums.DataTypeStructure
	default:
		return errors.New("GetDataType failed. Invalid attribute index.")
	}
}



// NewGXDLMSGXDLMSTokenGateway creates a new Token Gateway object instance.
//
// The function validates `ln` before creating the object.
//`ln` is the Logical Name and `sn` is the Short Name of the object.
func NewGXDLMSTokenGateway(ln string, sn int16) (*GXDLMSTokenGateway, error) {
	err := ValidateLogicalName(ln)
	if err != nil {
		return nil, err
	}
	return &GXDLMSTokenGateway {
		GXDLMSObject: GXDLMSObject{
			objectType:  enums.ObjectTypeTokenGateway,
			logicalName: ln,
			ShortName:   sn,
		},
	}, nil
}

