﻿package objects

//
// --------------------------------------------------------------------------
//  Gurux Ltd
//
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// More information of Gurux products: https://www.gurux.org
//
// This code is licensed under the GNU General Public License v2.
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

import (
	"fmt"
	"gurux.dlms"
	"github.com/Gurux/gxdlms-go/enums"
)

// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCompactData
type GXDLMSCompactData struct {
	GXDLMSObject
	// Capture objects.
	captureObjects []

	// Compact buffer
	Buffer []byte

	// Template ID.
	TemplateId uint8

	// Template description.
	TemplateDescription []byte

	// Capture method.
	CaptureMethod enums.CaptureMethod
}
// Base returns the base GXDLMSObject of the object.
func (g *GXDLMSCompactData) Base() *GXDLMSObject {
	return &g.GXDLMSObject
}

//Invoke returns the invokes method.
//
// Parameters:
//   settings: DLMS settings.
//   e: Invoke parameters.
func (g *GXDLMSCompactData) Invoke(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs)  ([]byte, error)  {
	if e.Index == 1 {
		g.Reset()
	} else if e.Index == 2 {
g.Capture(e.Server())	} else {
		e.Error = enums.ErrorCodeReadWriteDenied
	}
	return nil
}

//GetAttributeIndexToRead returns the collection of attributes to read.
// If attribute is static and already read or device is returned HW error it is not returned.
//
// Parameters:
//   all: All items are returned even if they are read already.
//
// Returns:
//   Collection of attributes to read.
func (g *GXDLMSCompactData) GetAttributeIndexToRead(all bool) []int {
	var attributes []int
	// LN is static and read only once.
	if all || g.LogicalName() == "" {
		attributes = append(attributes, 1)
	}
	// CaptureObjects
	if all || g.CanRead(3) {
		attributes = append(attributes, 3)
	}
	// TemplateDescription
	if all || g.CanRead(5) {
		attributes = append(attributes, 5)
	}
	// Buffer
	if all || g.CanRead(2) {
		attributes = append(attributes, 2)
	}
	// TemplateId
	if all || g.CanRead(4) {
		attributes = append(attributes, 4)
	}
	// CaptureMethod
	if all || g.CanRead(6) {
		attributes = append(attributes, 6)
	}
	return attributes
}

//GetNames returns the names of attribute indexes.
func (g *GXDLMSCompactData) GetNames() []string {
	return []string{"Logical Name", "Buffer", "CaptureObjects", "TemplateId", "TemplateDescription", "CaptureMethod"}
}

//GetMethodNames returns the names of method indexes.
func (g *GXDLMSCompactData) GetMethodNames() []string {
	return []string{"Reset", "Capture"}
}

//GetAttributeCount returns the amount of attributes.
//
// Returns:
//   Count of attributes.
func (g *GXDLMSCompactData) GetAttributeCount() int {
	return 6
}

//GetMethodCount returns the amount of methods.
func (g *GXDLMSCompactData) GetMethodCount() int {
	return 2
}

//GetCaptureObjects returns the captured objects.
//
// Parameters:
//   settings: DLMS settings.
func (g *GXDLMSCompactData) GetCaptureObjects(settings *settings.GXDLMSSettings) ([]byte, error) {
	data := GXByteBuffer{}
	err = data.SetUInt8(uint8(enums.DataTypeArray))	
	if err != nil {
		return err
	}
	GXCommon.SetObjectCount(len(g.captureObjects), data)
	for _, it := range g.captureObjects {
		err = data.SetUInt8(uint8(enums.DataTypeStructure))		
		if err != nil {
			return err
		}
		err = data.SetUInt8(4)		
		if err != nil {
			return err
		}
		// TODO: MIKKO: FAILED
		// GXCommon.SetData(settings, data, DataType.UInt16, it.Key.ObjectType);
		// Menetelmää tai toimintoa ei ole toteutettu.
		// TODO: MIKKO: FAILED
		// GXCommon.SetData(settings, data, DataType.OctetString, GXCommon.LogicalNameToBytes(it.Key.LogicalName));
		// Menetelmää tai toimintoa ei ole toteutettu.
		// TODO: MIKKO: FAILED
		// GXCommon.SetData(settings, data, DataType.Int8, it.Value.AttributeIndex);
		// Menetelmää tai toimintoa ei ole toteutettu.
		// TODO: MIKKO: FAILED
		// GXCommon.SetData(settings, data, DataType.UInt16, it.Value.DataIndex);
		// Menetelmää tai toimintoa ei ole toteutettu.
	}
	return data.Array(), nil
return err
}

//GetValue returns the value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Get parameters.
//
// Returns:
//   Value of the attribute index.
func (g *GXDLMSCompactData) GetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) (any, error) {
	switch (e.Index) {
	case 1:
		return GXCommon.LogicalNameToBytes(g.LogicalName)
	case 2:
		return Buffer
	case 3:
		return g.GetCaptureObjects(settings)
	case 4:
		return g.TemplateId
	case 5:
		return g.TemplateDescription
	case 6:
		return CaptureMethod
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
	return nil
}

// TODO: Comment is missing.
func (g *GXDLMSCompactData) SetCaptureObjects(settings *settings.GXDLMSSettings, list *[], array *IEnumerable)(, error) {
c := nil
	// TODO: MIKKO: FAILED
	// list.Clear();
	// Unknown method data type List.Clear
try{ {
		if array != nil {
			for _, tmp := range array {
				var it []
if _, ok := tmp.(List[any]); ok {
					it = []<any>(tmp)
				} else {
					it = [](any(tmp))
				}
				if g.Version == 0 && len(it) != 4 {
					return 0, GXDLMSException("Invalid structure format.")
				} else if g.Version == 1 && len(it) != 5 {
					return 0, GXDLMSException("Invalid structure format.")
				}
				v := int16(it[0])
				// TODO: MIKKO: FAILED
				// if (Enum.GetName(typeof(ObjectType), v) == nil)
				// {
				// list.Clear();
				// return;
				// }
				// typeof(ObjectType)
type = (ObjectType) v
				ln := helpers.ToLogicalName([]byte(it[1]))
				attributeIndex := int16(it[2])
				// If profile generic selective access is used.
				if attributeIndex < 0 {
					attributeIndex = 2
				}
				dataIndex := uint16(it[3])
restriction := nil
				if g.Version != 0 && len(it) > 4 {
s = (GXStructure) it[4]
					// TODO: MIKKO: FAILED
					// restriction = new GXDLMSRestriction();
					// Unknown exception type
					restriction.g.Type(RestrictionType(s[0]))
					restriction.g.From(s[1])
					restriction.g.To(s[2])
				}
obj := nil
				if settings != nil && settings.Objects() != nil {
					obj = .FindByLN(type, ln)
				}
				if obj == nil {
					// TODO: MIKKO: FAILED
					// obj = GXDLMSClient.CreateDLMSObject(settings, (int)type, nil, 0, ln, 0, 2);
					// Menetelmää tai toimintoa ei ole toteutettu.
					if c == nil {
						// TODO: MIKKO: FAILED
						// c = new GXDLMSConverter();
						// Unknown exception type
					}
					c.UpdateOBISCodeInformation(obj)
				}
				// TODO: MIKKO: FAILED
				// list.Add(new GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>(obj, new GXDLMSCaptureObject(attributeIndex, dataIndex, restriction)));
				// Menetelmää tai toimintoa ei ole toteutettu.
			}
		}
	}
}
catchException{ {
		// TODO: MIKKO: FAILED
		// list.Clear();
		// Unknown method data type List.Clear
	}
}

}

//SetValue returns the set value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Set parameters.
func (g *GXDLMSCompactData) SetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) error{
	switch (e.Index) {
	case 1:
		g.LogicalName = helpers.ToLogicalName(e.Value)
	case 2:
if _, ok := e.Value.([]byte); ok {
			 = []byte(e.Value)
		} else if _, ok := e.Value.(string); ok {
			 = GXCommon.HexToBytes(string(e.Value))
		}
	case 3:
g.SetCaptureObjects(settings, g.captureObjects, IEnumerable<any>(e.Value))		if settings != nil && settings.IsServer() {
g.UpdateTemplateDescription()		}
	case 4:
		g.TemplateId = uint8(e.Value)
	case 5:
		g.TemplateDescription = []byte(e.Value)
	case 6:
		 = CaptureMethod(e.Value.(types.GXEnum).Value)
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
}

//Load returns the load object content from XML.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSCompactData) Load(reader *GXXmlReader) error {
	Buffer, err = GXCommon.HexToBytes(reader.ReadElementContentAsString("Buffer")	
	if err != nil {
		return err
	})
	// TODO: MIKKO: FAILED
	// CaptureObjects.Clear();
	// Unknown method data type List.Clear
	if reader.IsStartElement("CaptureObjects", true) {
for(reader.IsStartElement("Item", true)) {
ot, err = (ObjectType) reader.ReadElementContentAsInt("ObjectType")			
			if err != nil {
				return err
			}
			ln := reader.ReadElementContentAsString("LN")
			ai := reader.ReadElementContentAsInt("Attribute")
			di := reader.ReadElementContentAsInt("Data")
			co := GXDLMSCaptureObject{ai, di}
			obj := reader.Objects.FindByLN(ot, ln)
			if obj == nil {
				// TODO: MIKKO: FAILED
				// obj = GXDLMSClient.CreateObject(ot);
				// Menetelmää tai toimintoa ei ole toteutettu.
				obj.g.LogicalName(ln)
			}
			// TODO: MIKKO: FAILED
			// CaptureObjects.Add(new GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>(obj, co));
			// Menetelmää tai toimintoa ei ole toteutettu.
		}
		reader.ReadEndElement("CaptureObjects")
	}
	g.TemplateId, err = uint8(reader.ReadElementContentAsInt("TemplateId")	
	if err != nil {
		return err
	})
	g.TemplateDescription, err = GXCommon.HexToBytes(reader.ReadElementContentAsString("TemplateDescription")	
	if err != nil {
		return err
	})
	CaptureMethod, err = CaptureMethod(reader.ReadElementContentAsInt("CaptureMethod")	
	if err != nil {
		return err
	})
return err
}

//Save returns the save object content to XML.
//
// Parameters:
//   writer: XML writer.
func (g *GXDLMSCompactData) Save(writer *GXXmlWriter) error {
	err = writer.WriteElementString("Buffer", GXCommon.ToHex(, false))	
	if err != nil {
		return err
	}
	writer.WriteStartElement("CaptureObjects")
	if len(g.captureObjects) != 0 {
		for _, it := range g.captureObjects {
			writer.WriteStartElement("Item")
			// TODO: MIKKO: FAILED
			// writer.WriteElementString("ObjectType", (int)it.Key.ObjectType);
			// Method is not implemented. .ObjectType
			// TODO: MIKKO: FAILED
			// writer.WriteElementString("LN", it.Key.LogicalName);
			// Method is not implemented. .LogicalName
			// TODO: MIKKO: FAILED
			// writer.WriteElementString("Attribute", it.Value.AttributeIndex);
			// Method is not implemented. .AttributeIndex
			// TODO: MIKKO: FAILED
			// writer.WriteElementString("Data", it.Value.DataIndex);
			// Method is not implemented. .DataIndex
			writer.WriteEndElement()
		}
	}
	writer.WriteEndElement()
	err = writer.WriteElementString("TemplateId", g.TemplateId)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("TemplateDescription", GXCommon.ToHex(g.TemplateDescription, false))	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("CaptureMethod", int())	
	if err != nil {
		return err
	}
return err
}

//PostLoad returns the handle actions after Load.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSCompactData) PostLoad(reader *GXXmlReader) {
	// TODO: MIKKO: FAILED
	// if (CaptureObjects != nil && CaptureObjects.Any())
	// {
	// List<GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>> columns = new List<GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>>();
	// foreach (var it in CaptureObjects)
	// {
	// var obj = it.Key;
	// GXDLMSObject target = reader.Objects.FindByLN(obj.ObjectType, obj.LogicalName);
	// if (target != nil && target != obj)
	// {
	// obj = target;
	// }
	// columns.Add(new GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>(obj, it.Value));
	// }
	// CaptureObjects.Clear();
	// CaptureObjects.AddRange(columns);
	// }
	// Unknown method data type List.Any
}

// TODO: Comment is missing.
func (g *GXDLMSCompactData) CaptureArray(server *dlms.GXDLMSServer, tmp *dlms.GXByteBuffer, bb *dlms.GXByteBuffer, index int) {
	tmp.Uint8()
	cnt := GXCommon.GetObjectCount(tmp)
	for pos := 0; pos != cnt; pos++ {
		if index == -1 || index == pos {
dt = (DataType) tmp.Uint8(tmp.Position())
			if dt == enums.DataTypeStructure || dt == enums.DataTypeArray {
				g.CaptureArray(server, tmp, bb, -1)
			} else {
				g.CaptureValue(server, tmp, bb)
			}
			if index == pos {
				break;
			}
		}
	}
}

// TODO: Comment is missing.
func (g *GXDLMSCompactData) CaptureValue(server *dlms.GXDLMSServer, tmp *dlms.GXByteBuffer, bb *dlms.GXByteBuffer) error {
	tmp2 := GXByteBuffer{}
	info := gxDataInfo{}
	value := GXCommon.GetData(server.Settings(), tmp, info)
	GXCommon.SetData(server.Settings(), tmp2, info.Type(), value)
	// If data is empty.
	if tmp2.Size() == 1 {
		err = bb.SetUInt8(0)		
		if err != nil {
			return err
		}
	} else {
		tmp2.G.position(1)
		err = bb.Set(tmp2)		
		if err != nil {
			return err
		}
	}
return err
}

// TODO: Comment is missing.
func (g *GXDLMSCompactData) UpdateTemplateDescription(columns *dlms.GXByteBuffer, data *dlms.GXByteBuffer, index int) error {
ch = (DataType) data.Uint8()
	count := GXCommon.GetObjectCount(data)
	if index == -1 {
		err = columns.SetUInt8(ch)		
		if err != nil {
			return err
		}
		if ch == enums.DataTypeArray {
			err = columns.SetUInt16(uint16(count))			
			if err != nil {
				return err
			}
		} else {
			err = columns.SetUInt8(uint8(count))			
			if err != nil {
				return err
			}
		}
	}
	info := gxDataInfo{}
	for pos := 0; pos < count; pos++ {
		// If all data is captured.
		if index == -1 || pos == index {
dt = (DataType) data.Uint8(data.Position())
			if dt == enums.DataTypeArray || dt == enums.DataTypeStructure {
				g.UpdateTemplateDescription(columns, data, -1)
				if ch == enums.DataTypeArray {
					break;
				}
			} else {
				info.Clear()
				err = columns.SetUInt8(uint8(dt))				
				if err != nil {
					return err
				}
				GXCommon.GetData(nil, data, info)
			}
			if index == pos {
				break;
			}
		}
	}
return err
}


//Capture returns the copies the values of the objects to capture
// into the buffer by reading capture objects.
func (g *GXDLMSCompactData) Capture(server *dlms.GXDLMSServer) {
}


//GetValues returns the an array containing the COSEM object's attribute values.
func (g *GXDLMSCompactData) GetValues() []any {
	return []any{g.LogicalName, , g.captureObjects, g.TemplateId, g.TemplateDescription, }
}

// TODO: Comment is missing.
func (g *GXDLMSCompactData) GetDataTypes(value []byte) [] {
	if value == nil || len(len(value)) == 0 {
		// TODO: MIKKO: FAILED
		// return new List<object>();
		// Unknown exception type
	}
	info := gxDataInfo{}
	// TODO: MIKKO: FAILED
	// object ret = GXCommon.GetCompactArray(nil, new GXByteBuffer(value), info, true);
	// Menetelmää tai toimintoa ei ole toteutettu.
	return ([]<any>(ret))
}

// TODO: Comment is missing.
func (g *GXDLMSCompactData) GetData(columns []byte, value []byte) ([], error) {
	if columns == nil || len(len(columns)) == 0 || value == nil || len(len(value)) == 0 {
		// TODO: MIKKO: FAILED
		// return new GXArray();
		// Unknown exception type
	}
	info := gxDataInfo{}
	bb := GXByteBuffer{}
	err = bb.Set(columns)	
	if err != nil {
		return err
	}
	GXCommon.SetObjectCount(len(len(value)), bb)
	err = bb.Set(value)	
	if err != nil {
		return err
	}
tmp = ([]<any>) GXCommon.GetCompactArray(nil, bb, info, false)
	return tmp, nil
return err
}

//GetDataType returns the device data type of selected attribute index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   Device data type of the object.
func (g *GXDLMSCompactData) GetDataType(index int) errorenums.DataType {
	switch (index) {
	case 1:
		return enums.DataTypeOctetString
	case 2:
		return enums.DataTypeOctetString
	case 3:
		return enums.DataTypeArray
	case 4:
		return enums.DataTypeUInt8
	case 5:
		return enums.DataTypeOctetString
	case 6:
		return enums.DataTypeEnum
	default:
		return errors.New("GetDataType failed. Invalid attribute index.")
	}
}

//Reset returns the clears the buffer.
func (g *GXDLMSCompactData) Reset() {
}

//Capture returns the copies the values of the objects to capture
// into the buffer by reading capture objects.
func (g *GXDLMSCompactData) Capture() {
	g.Capture(nil)
}

//UpdateTemplateDescription returns the update template description.
func (g *GXDLMSCompactData) UpdateTemplateDescription() {
}

//GetValues returns the convert compact data buffer to array of values.
//
// Parameters:
//   templateDescription: Template description byte array.
//   buffer: Buffer byte array.
//
// Returns:
//   Values from byte buffer.
func (g *GXDLMSCompactData) GetValues(templateDescription []byte, buffer []byte) ([], error) {
	// If templateDescription or buffer is not given.
	if templateDescription == nil || buffer == nil || len(len(templateDescription)) == 0 || len(len(buffer)) == 0 {
		return gxcommon.ErrInvalidArgument()
	}
	info := gxDataInfo{}
	var tmp any
	data := GXByteBuffer{}
	err = data.Set(templateDescription)	
	if err != nil {
		return err
	}
	GXCommon.SetObjectCount(len(len(buffer)), data)
	err = data.Set(buffer)	
	if err != nil {
		return err
	}
	info.G.type(enums.DataTypeCompactArray)
	tmp = GXCommon.GetData(nil, data, info)
	return []<any>(tmp), nil
}



// NewGXDLMSGXDLMSCompactData creates a new Compact Data object instance.
//
// The function validates `ln` before creating the object.
//`ln` is the Logical Name and `sn` is the Short Name of the object.
func NewGXDLMSCompactData(ln string, sn int16) (*GXDLMSCompactData, error) {
	err := ValidateLogicalName(ln)
	if err != nil {
		return nil, err
	}
	return &GXDLMSCompactData {
		GXDLMSObject: GXDLMSObject{
			objectType:  enums.ObjectTypeCompactData,
			logicalName: ln,
			ShortName:   sn,
		},
	}, nil
}

