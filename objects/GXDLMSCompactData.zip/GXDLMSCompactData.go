﻿package objects

//
// --------------------------------------------------------------------------
//  Gurux Ltd
//
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// More information of Gurux products: https://www.gurux.org
//
// This code is licensed under the GNU General Public License v2.
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

import (
	"fmt"
	"github.com/Gurux/gxdlms-go/enums"
)

// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSCompactData
type GXDLMSCompactData struct {
	GXDLMSObject
	// Capture objects.
	captureObjects []types.GXKeyValuePair[IGXDLMSBase, GXDLMSCaptureObject]

	// Compact buffer
	Buffer []byte

	// Template ID.
	TemplateId uint8

	// Template description.
	TemplateDescription []byte

	// Capture method.
	CaptureMethod enums.CaptureMethod
}
// Base returns the base GXDLMSObject of the object.
func (g *GXDLMSCompactData) Base() *GXDLMSObject {
	return &g.GXDLMSObject
}

//Invoke returns the invokes method.
//
// Parameters:
//   settings: DLMS settings.
//   e: Invoke parameters.
func (g *GXDLMSCompactData) Invoke(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs)  ([]byte, error)  {
	if e.Index == 1 {
		g.Reset()
	} else if e.Index == 2 {
g.Capture(e.Server())	
} else {
		e.Error = enums.ErrorCodeReadWriteDenied
	}
	return nil, nil
}

//GetAttributeIndexToRead returns the collection of attributes to read.
// If attribute is static and already read or device is returned HW error it is not returned.
//
// Parameters:
//   all: All items are returned even if they are read already.
//
// Returns:
//   Collection of attributes to read.
func (g *GXDLMSCompactData) GetAttributeIndexToRead(all bool) []int {
	var attributes []int
	// LN is static and read only once.
	if all || g.LogicalName() == "" {
		attributes = append(attributes, 1)
	}
	// CaptureObjects
	if all || g.CanRead(3) {
		attributes = append(attributes, 3)
	}
	// TemplateDescription
	if all || g.CanRead(5) {
		attributes = append(attributes, 5)
	}
	// Buffer
	if all || g.CanRead(2) {
		attributes = append(attributes, 2)
	}
	// TemplateId
	if all || g.CanRead(4) {
		attributes = append(attributes, 4)
	}
	// CaptureMethod
	if all || g.CanRead(6) {
		attributes = append(attributes, 6)
	}
	return attributes
}

//GetNames returns the names of attribute indexes.
func (g *GXDLMSCompactData) GetNames() []string {
	return []string{"Logical Name", "Buffer", "CaptureObjects", "TemplateId", "TemplateDescription", "CaptureMethod"}
}

//GetMethodNames returns the names of method indexes.
func (g *GXDLMSCompactData) GetMethodNames() []string {
	return []string{"Reset", "Capture"}
}

//GetAttributeCount returns the amount of attributes.
//
// Returns:
//   Count of attributes.
func (g *GXDLMSCompactData) GetAttributeCount() int {
	return 6
}

//GetMethodCount returns the amount of methods.
func (g *GXDLMSCompactData) GetMethodCount() int {
	return 2
}

//GetCaptureObjects returns the captured objects.
//
// Parameters:
//   settings: DLMS settings.
func (g *GXDLMSCompactData) GetCaptureObjects(settings *settings.GXDLMSSettings) ([]byte, error) {
	data := GXByteBuffer{}
	err = data.SetUint8(uint8(enums.DataTypeArray))	
	if err != nil {
		return err
	}
	GXCommon.SetObjectCount(len(g.captureObjects), data)
	for _, it := range g.captureObjects {
		err = data.SetUint8(uint8(enums.DataTypeStructure))		
		if err != nil {
			return err
		}
		err = data.SetUint8(4)		
		if err != nil {
			return err
		}
		 err = internal.SetData(settings,  data, enums.DataTypeUInt16, it.Key.ObjectType);
		if err != nil {
			return err
		}
		 err = internal.SetData(settings,  data, enums.DataTypeOctetString, helpers.LogicalNameToBytes(it.Key.LogicalName));
		if err != nil {
			return err
		}
		 err = internal.SetData(settings,  data, enums.DataTypeInt8, it.Value.AttributeIndex);
		if err != nil {
			return err
		}
		err = internal.SetData(settings,  data, enums.DataTypeUInt16, it.Value.DataIndex);
		if err != nil {
			return err
		}
	}
	return data.Array(), nil
}

//GetValue returns the value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Get parameters.
//
// Returns:
//   Value of the attribute index.
func (g *GXDLMSCompactData) GetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) (any, error) {
	switch (e.Index) {
	case 1:
		return helpers.LogicalNameToBytes(g.LogicalName)
	case 2:
		return Buffer
	case 3:
		return g.GetCaptureObjects(settings)
	case 4:
		return g.TemplateId
	case 5:
		return g.TemplateDescription
	case 6:
		return CaptureMethod
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
	return nil
}


func (g *GXDLMSCompactData) SetCaptureObjects(settings *settings.GXDLMSSettings, 
	list *[]types.GXKeyValuePair[IGXDLMSBase, GXDLMSCaptureObject], 
	array types.GXArray)error {
c := nil
	list = list[:0]
		if array != nil {
			for _, tmp := range array {
				it := tmp.(types.GXStructyre)
				if g.Version == 0 && len(it) != 4 {
					return errrs.New("Invalid structure format.")
				} else if g.Version == 1 && len(it) != 5 {
					return errrs.New("Invalid structure format.")
				}
				v := it[0].(int16)
				// TODO: MIKKO: FAILED
				// if (Enum.GetName(typeof(ObjectType), v) == nil)
				// {
				// list.Clear();
				// return;
				// }
				ot := enums.ObjectType(v)
				ln, err := helpers.ToLogicalName(it[1].([]byte))
				attributeIndex := it[2].(int16)
				// If profile generic selective access is used.
				if attributeIndex < 0 {
					attributeIndex = 2
				}
				dataIndex := uint16(it[3])
				restriction := nil
				if g.Version != 0 && len(it) > 4 {
					s := it[4].(types.GXStructure)
					restriction = GXDLMSRestriction();
					restriction.Type = enums.RestrictionType(s[0].(int))
					restriction.From = s[1]
					restriction.To = s[2]
				}
obj := nil
				if settings != nil && settings.Objects() != nil {
					obj = getObjectCollection(settings.Objects).FindByLN(ot, ln)
				}
				if obj == nil {
					 obj = CreateDLMSObject(ot, ln, 0, 2);
					if c == nil {
						// TODO: MIKKO: FAILED
						// c = new GXDLMSConverter();
						// Unknown exception type
					}
					//MIKKO c.UpdateOBISCodeInformation(obj)
				}
				 list = append(list, types.NewGXKeyValuePair(obj, NewGXDLMSCaptureObject(attributeIndex, dataIndex, restriction)));
			}
		}
	}

//SetValue returns the set value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Set parameters.
func (g *GXDLMSCompactData) SetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) error{
	switch (e.Index) {
	case 1:
		ln, err := helpers.ToLogicalName(e.Value)
		if err != nil {
			e.Error = enums.ErrorCodeReadWriteDenied
		}
		return g.SetLogicalName(ln)
	case 2:
		if v, ok := e.Value.([]byte); ok {
			g.Buffer = v
		} else if v, ok := e.Value.(string); ok {
			g.Buffer = types.HexToBytes(v)
		}
	case 3:
	g.SetCaptureObjects(settings, g.captureObjects, e.Value.(types.GXArray))
		if settings != nil && settings.IsServer() {
	g.UpdateTemplateDescription()		
}
	case 4:
		g.TemplateId = uint8(e.Value)
	case 5:
		g.TemplateDescription = []byte(e.Value)
	case 6:
		g.CaptureMethod = enums.CaptureMethod(e.Value.(types.GXEnum).Value)
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
}

//Load returns the load object content from XML.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSCompactData) Load(reader *GXXmlReader) error {
	ret, err := reader.ReadElementContentAsString("Buffer", "")
	if err != nil {
		return err
	}
	g.Buffer = internal.HexToBytes(ret)
	g.CaptureObjects = g.CaptureObjects[:0]
	if ret, err := reader.IsStartElementNamed("CaptureObjects", true); ret && err == nil {
		for {
			ret, err = reader.IsStartElementNamed("Item", true)
			if err != nil {
				return err
			}
			if !ret {
				break
			}
			ret, err = reader.ReadElementContentAsInt("ObjectType")			
			if err != nil {
				return err
			}
			ot := enums.ObjectType(ret) 
			ln := reader.ReadElementContentAsString("LN")
			ai := reader.ReadElementContentAsInt("Attribute")
			di := reader.ReadElementContentAsInt("Data")
			co := GXDLMSCaptureObject{ai, di}
			obj := reader.Objects.FindByLN(ot, ln)
			if obj == nil {
				obj, err = CreateObject(ot, ln, 0);
				if err != nil{
					return err
				}
			}
			g.CaptureObjects = append(g.CaptureObjects, *types.NewGXKeyValuePair(obj, co));
		}
		reader.ReadEndElement("CaptureObjects")
	}
	g.TemplateId, err = reader.ReadElementContentAsUInt8("TemplateId", 0)	
	if err != nil {
		return err
	}
	ret, err = reader.ReadElementContentAsString("TemplateDescription", "")	
	if err != nil {
		return err
	}
	g.TemplateDescription = types.HexToBytes(ret)
	ret, err = reader.ReadElementContentAsInt("CaptureMethod")	
	if err != nil {
		return err
	}
	g.CaptureMethod = enums.CaptureMethod(ret) 
	return err
}

//Save returns the save object content to XML.
//
// Parameters:
//   writer: XML writer.
func (g *GXDLMSCompactData) Save(writer *GXXmlWriter) error {
	err = writer.WriteElementString(g.Buffer)	
	if err != nil {
		return err
	}
	writer.WriteStartElement("CaptureObjects")
	if len(g.captureObjects) != 0 {
		for _, it := range g.captureObjects {
			writer.WriteStartElement("Item")
			writer.WriteElementString("ObjectType", int(it.Key.Base().ObjectType()));
			 writer.WriteElementString("LN", it.Key.Base().LogicalName());
			 writer.WriteElementString("Attribute", it.Value.AttributeIndex);
			 writer.WriteElementString("Data", it.Value.DataIndex);
			writer.WriteEndElement()
		}
	}
	writer.WriteEndElement()
	err = writer.WriteElementString("TemplateId", g.TemplateId)	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("TemplateDescription", types.ToHex(g.TemplateDescription, false))	
	if err != nil {
		return err
	}
	err = writer.WriteElementString("CaptureMethod", int())	
	if err != nil {
		return err
	}
return err
}

//PostLoad returns the handle actions after Load.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSCompactData) PostLoad(reader *GXXmlReader) error {
	// TODO: MIKKO: FAILED
	// if (CaptureObjects != nil && CaptureObjects.Any())
	// {
	// List<GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>> columns = new List<GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>>();
	// foreach (var it in CaptureObjects)
	// {
	// var obj = it.Key;
	// GXDLMSObject target = reader.Objects.FindByLN(obj.ObjectType, obj.LogicalName);
	// if (target != nil && target != obj)
	// {
	// obj = target;
	// }
	// columns.Add(new GXKeyValuePair<GXDLMSObject, GXDLMSCaptureObject>(obj, it.Value));
	// }
	// CaptureObjects.Clear();
	// CaptureObjects.AddRange(columns);
	// }
	// Unknown method data type List.Any
}


func (g *GXDLMSCompactData) CaptureArray(server *dlms.GXDLMSServer, tmp *dlms.GXByteBuffer, bb *dlms.GXByteBuffer, index int) {
	tmp.Uint8()
	cnt := GXCommon.GetObjectCount(tmp)
	for pos := 0; pos != cnt; pos++ {
		if index == -1 || index == pos {
			dt := enums.DataType( tmp.Uint8At(tmp.Position()))
			if dt == enums.DataTypeStructure || dt == enums.DataTypeArray {
				g.CaptureArray(server, tmp, bb, -1)
			} else {
				g.CaptureValue(server, tmp, bb)
			}
			if index == pos {
				break;
			}
		}
	}
}


func (g *GXDLMSCompactData) CaptureValue(server *dlms.GXDLMSServer, tmp *dlms.GXByteBuffer, bb *dlms.GXByteBuffer) error {
	tmp2 := GXByteBuffer{}
	info := gxDataInfo{}
	value := GXCommon.GetData(server.Settings(), tmp, info)
	err = internal.SetData(settings, server.Settings(), tmp2, info.Type(), value)
	// If data is empty.
	if tmp2.Size() == 1 {
		err = bb.SetUint8(0)		
		if err != nil {
			return err
		}
	} else {
		tmp2.G.position(1)
		err = bb.Set(tmp2)		
		if err != nil {
			return err
		}
	}
return err
}


func (g *GXDLMSCompactData) UpdateTemplateDescription(columns *dlms.GXByteBuffer, data *dlms.GXByteBuffer, index int) error {
	ret, err := data.Uint8()
		if err != nil {
			return err
		}
	ch := enums.DataType(ret) 
	count := GXCommon.GetObjectCount(data)
	if index == -1 {
		err = columns.SetUint8(ch)		
		if err != nil {
			return err
		}
		if ch == enums.DataTypeArray {
			err = columns.SetUInt16(uint16(count))			
			if err != nil {
				return err
			}
		} else {
			err = columns.SetUint8(uint8(count))			
			if err != nil {
				return err
			}
		}
	}
	info := gxDataInfo{}
	for pos := 0; pos < count; pos++ {
		// If all data is captured.
		if index == -1 || pos == index {
			ret, err :=  data.Uint8At(data.Position())
				if err != nil {
					return err
				}
			dt = enums.DataType(ret)
			if dt == enums.DataTypeArray || dt == enums.DataTypeStructure {
				g.UpdateTemplateDescription(columns, data, -1)
				if ch == enums.DataTypeArray {
					break;
				}
			} else {
				info.Clear()
				err = columns.SetUint8(uint8(dt))				
				if err != nil {
					return err
				}
				err = internal.GetData(nil, data, info)
				if err != nil {
					return err
				}
			}
			if index == pos {
				break;
			}
		}
	}
return err
}


//Capture returns the copies the values of the objects to capture
// into the buffer by reading capture objects.
func (g *GXDLMSCompactData) Capture(server *dlms.GXDLMSServer) {
}


//GetValues returns the an array containing the COSEM object's attribute values.
func (g *GXDLMSCompactData) GetValues() []any {
	return []any{g.LogicalName(), g.Buffer , g.captureObjects, g.TemplateId, g.TemplateDescription, g.CaptureMethod}
}

func (g *GXDLMSCompactData) GetDataTypes(value []byte) []any {
	if len(value) == 0 {
		return nil
	}
	info := gxDataInfo{}
	ret = GXCommon.GetCompactArray(nil, new GXByteBuffer(value), info, true);
	return ([]<any>(ret))
}


func (g *GXDLMSCompactData) GetData(columns []byte, value []byte) ([], error) {
	if columns == nil || len(len(columns)) == 0 || value == nil || len(len(value)) == 0 {
		// TODO: MIKKO: FAILED
		// return new GXArray();
		// Unknown exception type
	}
	info := gxDataInfo{}
	bb := GXByteBuffer{}
	err = bb.Set(columns)	
	if err != nil {
		return err
	}
	GXCommon.SetObjectCount(len(len(value)), bb)
	err = bb.Set(value)	
	if err != nil {
		return err
	}
tmp = ([]<any>) GXCommon.GetCompactArray(nil, bb, info, false)
	return tmp, nil
return err
}

//GetDataType returns the device data type of selected attribute index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   Device data type of the object.
func (g *GXDLMSCompactData) GetDataType(index int) (enums.DataType, error) {
	var ret enums.DataType
	var err error
	switch (index) {
	case 1:
		ret = enums.DataTypeOctetString
	case 2:
		ret =  enums.DataTypeOctetString
	case 3:
		ret =  enums.DataTypeArray
	case 4:
		ret =  enums.DataTypeUInt8
	case 5:
		ret =  enums.DataTypeOctetString
	case 6:
		ret =  enums.DataTypeEnum
	default:
		err =  errors.New("GetDataType failed. Invalid attribute index.")
	}
	return ret, err
}

//Reset returns the clears the buffer.
func (g *GXDLMSCompactData) Reset() {
}

//Capture returns the copies the values of the objects to capture
// into the buffer by reading capture objects.
func (g *GXDLMSCompactData) Capture() {
	g.Capture(nil)
}

//UpdateTemplateDescription returns the update template description.
func (g *GXDLMSCompactData) UpdateTemplateDescription() {
}

//GetValues returns the convert compact data buffer to array of values.
//
// Parameters:
//   templateDescription: Template description byte array.
//   buffer: Buffer byte array.
//
// Returns:
//   Values from byte buffer.
func (g *GXDLMSCompactData) GetValues(templateDescription []byte, buffer []byte) ([], error) {
	// If templateDescription or buffer is not given.
	if templateDescription == nil || buffer == nil || len(len(templateDescription)) == 0 || len(len(buffer)) == 0 {
		return gxcommon.ErrInvalidArgument()
	}
	info := gxDataInfo{}
	var tmp any
	data := GXByteBuffer{}
	err = data.Set(templateDescription)	
	if err != nil {
		return err
	}
	GXCommon.SetObjectCount(len(len(buffer)), data)
	err = data.Set(buffer)	
	if err != nil {
		return err
	}
	info.G.type(enums.DataTypeCompactArray)
	tmp = GXCommon.GetData(nil, data, info)
	return []<any>(tmp), nil
}



// NewGXDLMSGXDLMSCompactData creates a new Compact Data object instance.
//
// The function validates `ln` before creating the object.
//`ln` is the Logical Name and `sn` is the Short Name of the object.
func NewGXDLMSCompactData(ln string, sn int16) (*GXDLMSCompactData, error) {
	err := ValidateLogicalName(ln)
	if err != nil {
		return nil, err
	}
	return &GXDLMSCompactData {
		GXDLMSObject: GXDLMSObject{
			objectType:  enums.ObjectTypeCompactData,
			logicalName: ln,
			ShortName:   sn,
		},
	}, nil
}

