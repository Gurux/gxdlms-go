﻿package objects

//
// --------------------------------------------------------------------------
//  Gurux Ltd
//
//
//
// Filename:        $HeadURL$
//
// Version:         $Revision$,
//                  $Date$
//                  $Author$
//
// Copyright (c) Gurux Ltd
//
//---------------------------------------------------------------------------
//
//  DESCRIPTION
//
// This file is a part of Gurux Device Framework.
//
// Gurux Device Framework is Open Source software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; version 2 of the License.
// Gurux Device Framework is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// More information of Gurux products: https://www.gurux.org
//
// This code is licensed under the GNU General Public License v2.
// Full text may be retrieved at http://www.gnu.org/licenses/gpl-2.0.txt
//---------------------------------------------------------------------------

import (
	"errors"
	"strings"
	"time"

	"github.com/Gurux/gxdlms-go/enums"
	"github.com/Gurux/gxdlms-go/internal"
	"github.com/Gurux/gxdlms-go/internal/helpers"
	"github.com/Gurux/gxdlms-go/settings"
	"github.com/Gurux/gxdlms-go/types"
)

// Online help:
// https://www.gurux.fi/Gurux.DLMS.Objects.GXDLMSParameterMonitor
type GXDLMSParameterMonitor struct {
	GXDLMSObject
	// Changed parameter.
	ChangedParameter GXDLMSTarget

	// Capture time.
	CaptureTime time.Time

	// Changed Parameter
	Parameters []GXDLMSTarget
}

// Base returns the base GXDLMSObject of the object.
func (g *GXDLMSParameterMonitor) Base() *GXDLMSObject {
	return &g.GXDLMSObject
}

//Invoke returns the invokes method.
//
// Parameters:
//   settings: DLMS settings.
//   e: Invoke parameters.
func (g *GXDLMSParameterMonitor) Invoke(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) ([]byte, error) {
	if e.Index != 1 && e.Index != 2 {
		e.Error = enums.ErrorCodeReadWriteDenied
	} else {
		if e.Index == 1 {
			tmp = e.Parameters().(types.GXStructure)
			ot := enums.ObjectType(tmp[0].(uint16))
			ln := helpers.ToLogicalName([]byte(tmp[1]))
			index := Convert.ToByte(tmp[2])
			for _, item := range g.Parameters {
				if item.Target.G.objectType == ot && item.Target.LogicalName() == ln && item.AttributeIndex() == index {
					g.Parameters.Remove(item)
					break
				}
			}
			it := &GXDLMSTarget{}
			it.Target = settings.items.FindByLN(ot, tmp[1].([]byte))
			if it.Target() == nil {
				it.Target = CreateObject(ot, ln, 0)
			}
			it.AttributeIndex = index
			g.Parameters = append(g.Parameters, it)
		} else if e.Index == 2 {
			tmp := e.Parameters().(types.GXStructure)
			ot := enums.ObjectType(tmp[0].(uint16))
			ln := helpers.ToLogicalName([]byte(tmp[1]))
			index := Convert.ToByte(tmp[2])
			for _, item := range g.Parameters {
				if item.Target.G.objectType == ot && item.Target.g.LogicalName == ln && item.AttributeIndex() == index {
					Parameters.Remove(item)
					break
				}
			}
		}
	}
	return nil
}

//GetAttributeIndexToRead returns the collection of attributes to read.
// If attribute is static and already read or device is returned HW error it is not returned.
//
// Parameters:
//   all: All items are returned even if they are read already.
//
// Returns:
//   Collection of attributes to read.
func (g *GXDLMSParameterMonitor) GetAttributeIndexToRead(all bool) []int {
	var attributes []int
	// LN is static and read only once.
	if all || g.LogicalName() == "" {
		attributes = append(attributes, 1)
	}
	// ChangedParameter
	if all || g.CanRead(2) {
		attributes = append(attributes, 2)
	}
	// CaptureTime
	if all || g.CanRead(3) {
		attributes = append(attributes, 3)
	}
	// Parameters
	if all || g.CanRead(4) {
		attributes = append(attributes, 4)
	}
	return attributes
}

//GetNames returns the names of attribute indexes.
func (g *GXDLMSParameterMonitor) GetNames() []string {
	return []string{"Logical Name", "ChangedParameter", "CaptureTime", "Parameters"}
}

//GetMethodNames returns the names of method indexes.
func (g *GXDLMSParameterMonitor) GetMethodNames() []string {
	return []string{"Add parameter", "Delete parameter"}
}

//GetAttributeCount returns the amount of attributes.
//
// Returns:
//   Count of attributes.
func (g *GXDLMSParameterMonitor) GetAttributeCount() int {
	return 4
}

//GetMethodCount returns the amount of methods.
func (g *GXDLMSParameterMonitor) GetMethodCount() int {
	return 2
}

//GetValue returns the value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Get parameters.
//
// Returns:
//   Value of the attribute index.
func (g *GXDLMSParameterMonitor) GetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) (any, error) {
	switch e.Index {
	case 1:
		return helpers.LogicalNameToBytes(g.LogicalName)
	case 2:
		{
			data := GXByteBuffer{}
			err = data.SetUint8(uint8(enums.DataTypeStructure))
			if err != nil {
				return err
			}
			err = data.SetUint8(4)
			if err != nil {
				return err
			}
			if g.ChangedParameter == nil || g.ChangedParameter.Target == nil {
				err = internal.SetData(settings, data, enums.DataTypeUInt16, 0)
				if err != nil {
					return err
				}
				ln := []byte{0, 0, 0, 0, 0, 0}
				err = internal.SetData(settings, data, enums.DataTypeOctetString, ln)
				if err != nil {
					return err
				}
				err = internal.SetData(settings, data, enums.DataTypeInt8, 1)
				if err != nil {
					return err
				}
				err = internal.SetData(settings, data, enums.DataTypeNone, nil)
				if err != nil {
					return err
				}
			} else {
				err = internal.SetData(settings, data, enums.DataTypeUInt16, ChangedParameter.Target.ObjectType)
				if err != nil {
					return err
				}
				ln, err := helpers.LogicalNameToBytes(ChangedParameter.Target.g.LogicalName)
				if err != nil {
					return err
				}

				err = internal.SetData(settings, data, enums.DataTypeOctetString, ln)
				if err != nil {
					return err
				}
				err = internal.SetData(settings, data, enums.DataTypeInt8, g.ChangedParameter.AttributeIndex)
				if err != nil {
					return err
				}
				err = internal.SetData(settings, data, GXDLMSConverter.GetDLMSDataType(g.ChangedParameter.Value), g.ChangedParameter.Value)
				if err != nil {
					return err
				}
			}
			return data.Array(), nil
		}
	case 3:
		return g.CaptureTime, nil
	case 4:
		{
			data := GXByteBuffer{}
			err = data.SetUint8(uint8(enums.DataTypeArray))
			if err != nil {
				return err
			}
			if g.Parameters == nil {
				err = data.SetUint8(0)
				if err != nil {
					return err
				}
			} else {
				err = data.SetUint8(uint8(len(g.Parameters)))
				if err != nil {
					return err
				}
				for _, it := range g.Parameters {
					err = data.SetUint8(uint8(enums.DataTypeStructure))
					if err != nil {
						return err
					}
					err = data.SetUint8(uint8(3))
					if err != nil {
						return err
					}
					err = internal.SetData(settings, data, enums.DataTypeUInt16, it.Target.G.objectType)
					err = internal.SetData(settings, data, enums.DataTypeOctetString, helpers.LogicalNameToBytes(it.Target.g.LogicalName))
					err = internal.SetData(settings, data, enums.DataTypeInt8, it.AttributeIndex())
				}
			}
			return data.Array(), nil
		}
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
	return nil, nil
	return err
}

//SetValue returns the set value of given attribute.
// When raw parameter us not used example register multiplies value by scalar.
//
// Parameters:
//   settings: DLMS settings.
//   e: Set parameters.
func (g *GXDLMSParameterMonitor) SetValue(settings *settings.GXDLMSSettings, e *internal.ValueEventArgs) error {
	switch e.Index {
	case 1:
		ln, err := helpers.ToLogicalName(e.Value)
		if err != nil {
			e.Error = enums.ErrorCodeReadWriteDenied
		}
		return g.SetLogicalName(ln)
	case 2:
		g.ChangedParameter = NewGXDLMSTarget()
		tmp := nil
		if tmp, ok := e.Value.types.GXStructure; ok {
			if len(tmp) != 4 {
				return 0, GXDLMSException("Invalid structure format.")
			}
			ot := enums.ObjectType(tmp[0].(int16))
			ln, err := helpers.ToLogicalName(tmp[1].([]byte))
			if err != nil {
				return err
			}
			g.ChangedParameter.Target = getObjectCollection(settings.Objects).FindByLN(ot, ln)
			if g.ChangedParameter.Target == nil {
				g.ChangedParameter.Target = GXDLMSClient.CreateObject(ot, ln, 0)
			}
			g.ChangedParameter.AttributeIndex = tmp[2].(byte)
			g.ChangedParameter.Value = tmp[3]
		}
	case 3:
		{
			if e.Value == nil {
				g.CaptureTime = GXDateTime(MinValue)
			} else {
				if _, ok := e.Value.([]byte); ok {
					e.v.Value(GXDLMSClient.ChangeType([]byte(e.Value), enums.DataTypeDateTime, settings.UseUtc2NormalTime()))
				} else if _, ok := e.Value.(string); ok {
					e.v.Value(GXDateTime(string(e.Value)))
				}
				if _, ok := e.Value.(GXDateTime); ok {
					g.CaptureTime = GXDateTime(e.Value)
				} else if _, ok := e.Value.(string); ok {
					var tm time.Time
					if _, ok := e.Value.(string); ok {
						// TODO: MIKKO: FAILED
						// CaptureTime = DateTime.ParseExact((String)e.Value, CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern + " " + CultureInfo.CurrentCulture.DateTimeFormat.LongTimePattern, CultureInfo.CurrentUICulture);
						// Menetelmää tai toimintoa ei ole toteutettu.
					} else {
						g.CaptureTime = tm
					}
				} else {
					g.CaptureTime = Convert.ToDateTime(e.Value)
				}
			}
		}
	case 4:
		{
			g.Parameters = g.Parameters[:0]
			if e.Value != nil {
				for _, it := range e.Value.(types.GXArray) {
					tmp := it.(types.GXStructure)
					if len(tmp) != 3 {
						return 0, GXDLMSException("Invalid structure format.")
					}
					obj := GXDLMSTarget{}
					ot := enums.ObjectType(tmp[0].(int16))
					ln, err := helpers.ToLogicalName(tmp[1].([]byte))
					obj.g.Target = getObjectCollection(settings.Objects).FindByLN(ot, ln)
					if obj.Target == nil {
						obj.Target = CreateObject(ot, ln, 0)
					}
					obj.g.AttributeIndex(Convert.ToByte(tmp[2]))
					g.Parameters = append(g.Parameters, obj)
				}
			}
		}
	default:
		e.Error = enums.ErrorCodeReadWriteDenied
	}
}

//Load returns the load object content from XML.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSParameterMonitor) Load(reader *GXXmlReader) error {
	var err error
	g.ChangedParameter = GXDLMSTarget{}
	if reader.IsStartElement("ChangedParameter", true) {
		ret, err = reader.ReadElementContentAsInt("Type")
		if err != nil {
			return err
		}
		ot := enums.ObjectType(ret)
		ln := reader.ReadElementContentAsString("LN")
		ChangedParameter.Target = getObjectCollection(settings.Objects).FindByLN(ot, ln)
		if g.ChangedParameter.Target == nil {
			ChangedParameter.Target, err = GXDLMSClient.CreateObject(ot, ln, 0)
			if err != nil {
				return err
			}
		}
		ChangedParameter.AttributeIndex, err = reader.ReadElementContentAsUInt8("Index")
		if err != nil {
			return err
		}
		ret, err := reader.ReadElementContentAsObject("Value", nil, nil, 0)
		if err != nil {
			return err
		}
		ChangedParameter.Value = ret
		reader.ReadEndElement("ChangedParameter")
	}
	if strings.EqualFold("Time", reader.g.name) {
		g.CaptureTime, err = reader.ReadElementContentAsGXDateTime("Time")
		if err != nil {
			return err
		}
	} else {
		g.CaptureTime = MinValue
	}
	g.Parameters = g.Parameters[:0]
	if reader.IsStartElement("Parameters", true) {
		for reader.IsStartElement("Item", true) {
			obj := GXDLMSTarget{}
			ret, err = reader.ReadElementContentAsInt("Type")
			if err != nil {
				return err
			}
			ot := enums.ObjectType(ret)
			ln := reader.ReadElementContentAsString("LN")
			obj.g.Target(getObjectCollection(settings.Objects).FindByLN(ot, ln))
			if obj.Target() == nil {
				obj.Target, err = CreateObject(ot, ln)
			}
			obj.AttributeIndex, err = reader.ReadElementContentAsUInt8("Index")
			if err != nil {
				return err
			}
			g.Parameters = append(g.Parameters, obj)
		}
		reader.ReadEndElement("Parameters")
	}
	return err
}

//Save returns the save object content to XML.
//
// Parameters:
//   writer: XML writer.
func (g *GXDLMSParameterMonitor) Save(writer *GXXmlWriter) error {
	writer.WriteStartElement("ChangedParameter")
	if g.ChangedParameter != nil && g.ChangedParameter.Target != nil {
		err = writer.WriteElementString("Type", int(ChangedParameter.Target.G.objectType))
		if err != nil {
			return err
		}
		err = writer.WriteElementString("LN", ChangedParameter.Target.g.LogicalName)
		if err != nil {
			return err
		}
		err = writer.WriteElementString("Index", g.ChangedParameter.AttributeIndex)
		if err != nil {
			return err
		}
		err = writer.WriteElementObject("Value", g.ChangedParameter.Value)
		if err != nil {
			return err
		}
	}
	writer.WriteEndElement()
	err = writer.WriteElementString("Time", g.CaptureTime)
	if err != nil {
		return err
	}
	writer.WriteStartElement("Parameters")
	if g.Parameters != nil && len(g.Parameters) != 0 {
		for _, it := range g.Parameters {
			writer.WriteStartElement("Item")
			err = writer.WriteElementString("Type", int(it.Target.G.objectType))
			if err != nil {
				return err
			}
			err = writer.WriteElementString("LN", it.Target.g.LogicalName)
			if err != nil {
				return err
			}
			err = writer.WriteElementString("Index", it.AttributeIndex())
			if err != nil {
				return err
			}
			writer.WriteEndElement()
		}
	}
	writer.WriteEndElement()
	return err
}

//PostLoad returns the handle actions after Load.
//
// Parameters:
//   reader: XML reader.
func (g *GXDLMSParameterMonitor) PostLoad(reader *GXXmlReader) error {
	return nil
}

//GetValues returns the an array containing the COSEM object's attribute values.
func (g *GXDLMSParameterMonitor) GetValues() []any {
	return []any{g.LogicalName(), g.ChangedParameter, g.CaptureTime, g.Parameters}
}

//Insert returns the inserts a new entry in the table.
func (g *GXDLMSParameterMonitor) Insert(client IGXDLMSClient, entry *GXDLMSTarget) ([][]uint8, error) {
	bb := GXByteBuffer{}
	err = bb.SetUint8(enums.DataTypeStructure)
	if err != nil {
		return err
	}
	err = bb.SetUint8(3)
	if err != nil {
		return err
	}
	err = internal.SetData(settings, nil, bb, enums.DataTypeUInt16, entry.Target.G.objectType)
	if err != nil {
		return err
	}
	err = internal.SetData(settings, nil, bb, enums.DataTypeOctetString, helpers.LogicalNameToBytes(entry.Target.g.LogicalName))
	if err != nil {
		return err
	}
	err = internal.SetData(settings, nil, bb, enums.DataTypeInt8, entry.AttributeIndex())
	if err != nil {
		return err
	}
	return client.Method(g, 1, bb.Array(), enums.DataTypeArray), nil
	return err
}

//Delete returns the deletes an entry from the table.
func (g *GXDLMSParameterMonitor) Delete(client IGXDLMSClient, entry *GXDLMSTarget) ([][]uint8, error) {
	bb := GXByteBuffer{}
	err = bb.SetUint8(enums.DataTypeStructure)
	if err != nil {
		return err
	}
	err = bb.SetUint8(3)
	if err != nil {
		return err
	}
	err = internal.SetData(settings, nil, bb, enums.DataTypeUInt16, entry.Target.G.objectType)
	if err != nil {
		return err
	}
	err = internal.SetData(settings, nil, bb, enums.DataTypeOctetString, helpers.LogicalNameToBytes(entry.Target.g.LogicalName))
	if err != nil {
		return err
	}
	err = internal.SetData(settings, nil, bb, enums.DataTypeInt8, entry.AttributeIndex())
	if err != nil {
		return err
	}
	return client.Method(g, 2, bb.Array(), enums.DataTypeArray), nil
}

//GetDataType returns the device data type of selected attribute index.
//
// Parameters:
//   index: Attribute index of the object.
//
// Returns:
//   Device data type of the object.
func (g *GXDLMSParameterMonitor) GetDataType(index int) (enums.DataType, error) {
	var ret enums.DataType
	var err error
	switch index {
	case 1:
		ret = enums.DataTypeOctetString
	case 2:
		ret = enums.DataTypeStructure
	case 3:
		ret = enums.DataTypeOctetString
	case 4:
		ret = enums.DataTypeArray
	default:
		err = errors.New("GetDataType failed. Invalid attribute index.")
	}
	return ret, err
}

// NewGXDLMSGXDLMSParameterMonitor creates a new Parameter Monitor object instance.
//
// The function validates `ln` before creating the object.
//`ln` is the Logical Name and `sn` is the Short Name of the object.
func NewGXDLMSParameterMonitor(ln string, sn int16) (*GXDLMSParameterMonitor, error) {
	err := ValidateLogicalName(ln)
	if err != nil {
		return nil, err
	}
	return &GXDLMSParameterMonitor{
		GXDLMSObject: GXDLMSObject{
			objectType:  enums.ObjectTypeParameterMonitor,
			logicalName: ln,
			ShortName:   sn,
		},
	}, nil
}
